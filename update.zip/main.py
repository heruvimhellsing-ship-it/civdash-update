#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Civ4Col / We The People — tournament log dashboard.

Run with no arguments  -> graphical window (pick a folder, click build).
Run with a folder path -> command line (batch / scripting).

    CivDashboard.exe                       # GUI
    CivDashboard.exe "C:\\path\\to\\logs"    # CLI
    CivDashboard.exe "C:\\logs" out.html --open
"""
import os
import sys
import argparse
import webbrowser

# Under a PyInstaller --noconsole (--windowed) build, sys.stdout / sys.stderr are
# None. Any print() then raises AttributeError and can crash the GUI when a broken
# log file is skipped (the skip paths print diagnostics). Route writes to a sink so
# print() is always safe, in every mode.
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')

# Make the package importable both from source and from a PyInstaller bundle.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from civdash import pipeline, __version__


def run_cli(args):
    def prog(done, total, fname):
        pct = int(done / total * 100) if total else 100
        sys.stdout.write("\r  [%3d%%] %d/%d  %-40s" % (pct, done, total, fname[:40]))
        sys.stdout.flush()

    print("Civ Dashboard v%s" % __version__)
    print("Папка логов: %s" % args.folder)
    out, stats = pipeline.generate(args.folder, args.output, progress=prog)
    print()
    print("Готово: %s" % out)
    print("  игроков: %d   (старый формат: %d, новый: %d, пропущено пустых: %d, ошибок: %d)"
          % (stats['players'], stats['legacy'], stats['ideal'],
             stats['skipped_empty'], stats['errors']))
    print("  размер: %.1f МБ" % (stats['bytes'] / 1024 / 1024))
    if args.open:
        webbrowser.open('file://' + os.path.abspath(out))
    return 0


def run_gui():
    import threading
    import queue
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    root = tk.Tk()
    root.title("Civ4Col — Дашборд по логам  v%s" % __version__)
    root.geometry("640x340")
    root.minsize(560, 300)

    state = {'folder': '', 'out': '', 'busy': False}
    q = queue.Queue()

    frm = ttk.Frame(root, padding=18)
    frm.pack(fill='both', expand=True)

    ttk.Label(frm, text="Оценка игроков — Colonization / We The People",
              font=('Segoe UI', 13, 'bold')).pack(anchor='w')
    ttk.Label(frm, text="Выбери папку с логами (*.txt). Программа разберёт их и соберёт дашборд одним файлом.",
              foreground='#555').pack(anchor='w', pady=(2, 14))

    row = ttk.Frame(frm)
    row.pack(fill='x')
    path_var = tk.StringVar(value="папка не выбрана")
    ttk.Entry(row, textvariable=path_var, state='readonly').pack(side='left', fill='x', expand=True)

    def pick():
        d = filedialog.askdirectory(title="Папка с логами")
        if d:
            state['folder'] = d
            path_var.set(d)
            build_btn.config(state='normal')
            status_var.set("Готово к сборке.")

    ttk.Button(row, text="Выбрать папку…", command=pick).pack(side='left', padx=(8, 0))

    pbar = ttk.Progressbar(frm, mode='determinate', maximum=100)
    pbar.pack(fill='x', pady=(16, 6))
    status_var = tk.StringVar(value="Ожидание выбора папки…")
    ttk.Label(frm, textvariable=status_var, foreground='#333').pack(anchor='w')

    btns = ttk.Frame(frm)
    btns.pack(fill='x', pady=(16, 0))

    def worker(folder):
        def prog(done, total, fname):
            q.put(('progress', done, total, fname))
        try:
            out, stats = pipeline.generate(folder, progress=prog)
            q.put(('done', out, stats))
        except Exception as e:  # surface any failure to the UI thread
            q.put(('error', str(e)))

    def start_build():
        if state['busy'] or not state['folder']:
            return
        state['busy'] = True
        build_btn.config(state='disabled')
        pick_disable()
        open_btn.config(state='disabled')
        pbar.config(value=0)
        status_var.set("Читаю логи…")
        threading.Thread(target=worker, args=(state['folder'],), daemon=True).start()
        root.after(80, pump)

    def pump():
        try:
            while True:
                msg = q.get_nowait()
                if msg[0] == 'progress':
                    _, done, total, fname = msg
                    pbar.config(value=(done / total * 100) if total else 100)
                    status_var.set("Разбор логов: %d / %d   %s" % (done, total, fname[:38]))
                elif msg[0] == 'done':
                    _, out, stats = msg
                    state['out'] = out
                    state['busy'] = False
                    pbar.config(value=100)
                    status_var.set("Готово: %d игроков  ·  %d старых + %d новых  ·  %.1f МБ"
                                   % (stats['players'], stats['legacy'], stats['ideal'],
                                      stats['bytes'] / 1024 / 1024))
                    build_btn.config(state='normal')
                    pick_enable()
                    open_btn.config(state='normal')
                    if stats['errors'] or stats['skipped_empty']:
                        status_var.set(status_var.get() +
                                       "  (пропущено пустых: %d, ошибок: %d)"
                                       % (stats['skipped_empty'], stats['errors']))
                    return
                elif msg[0] == 'error':
                    state['busy'] = False
                    build_btn.config(state='normal')
                    pick_enable()
                    status_var.set("Ошибка.")
                    messagebox.showerror("Ошибка", msg[1])
                    return
        except queue.Empty:
            pass
        root.after(80, pump)

    def open_result():
        if state['out']:
            webbrowser.open('file://' + os.path.abspath(state['out']))

    build_btn = ttk.Button(btns, text="Построить дашборд", command=start_build, state='disabled')
    build_btn.pack(side='left')
    open_btn = ttk.Button(btns, text="Открыть дашборд", command=open_result, state='disabled')
    open_btn.pack(side='left', padx=(8, 0))

    # ---- онлайн-обновление программы (тянет код с GitHub, данные никуда не уходят) ----
    uq = queue.Queue()

    def check_update():
        if state['busy']:
            return
        upd_btn.config(state='disabled')
        status_var.set("Проверяю обновления…")

        def work():
            try:
                from civdash import updater
                man = updater.fetch_manifest()
                remote = man.get('version', '0')
                if not updater.is_newer(remote, __version__):
                    uq.put(('none', remote))
                    return
                base_dir = os.path.dirname(os.path.abspath(__file__))
                updater.apply_update(base_dir, man)
                uq.put(('done', remote, man.get('notes', '')))
            except Exception as e:
                uq.put(('error', str(e)))

        threading.Thread(target=work, daemon=True).start()
        root.after(120, upd_pump)

    def upd_pump():
        try:
            while True:
                m = uq.get_nowait()
                if m[0] == 'none':
                    status_var.set("У вас последняя версия v%s." % m[1])
                    upd_btn.config(state='normal')
                    messagebox.showinfo("Обновление", "У вас уже последняя версия (v%s)." % m[1])
                    return
                elif m[0] == 'done':
                    status_var.set("Обновлено до v%s — перезапустите программу." % m[1])
                    upd_btn.config(state='normal')
                    messagebox.showinfo(
                        "Обновление установлено",
                        "Установлена версия v%s.\n\nЧто нового:\n%s\n\nЗакройте и откройте программу "
                        "заново, чтобы изменения вступили в силу." % (m[1], m[2] or '—'))
                    return
                elif m[0] == 'error':
                    status_var.set("Не удалось обновиться.")
                    upd_btn.config(state='normal')
                    messagebox.showerror(
                        "Обновление",
                        "Не получилось проверить/скачать обновление:\n%s\n\n"
                        "Проверьте интернет и попробуйте позже." % m[1])
                    return
        except queue.Empty:
            pass
        root.after(120, upd_pump)

    upd_btn = ttk.Button(btns, text="Обновить программу", command=check_update)
    upd_btn.pack(side='right')

    pick_btn_ref = row.winfo_children()[-1]
    def pick_disable(): pick_btn_ref.config(state='disabled')
    def pick_enable(): pick_btn_ref.config(state='normal')

    ttk.Label(frm, text="Дашборд сохранится файлом dashboard.html в той же папке с логами.",
              foreground='#888').pack(anchor='w', side='bottom')

    root.mainloop()


def _has_logs(folder):
    """True if the folder directly contains at least one *.txt."""
    try:
        return any(f.lower().endswith('.txt') for f in os.listdir(folder))
    except OSError:
        return False


def _resolve_target(paths):
    """From dropped/passed paths pick the logs folder: a dropped folder as-is,
    or the parent folder of dropped file(s)."""
    for p in paths:
        if p and os.path.isdir(p):
            return p
    for p in paths:
        if p and os.path.isfile(p):
            return os.path.dirname(os.path.abspath(p))
    return None


def _popup(kind, title, text):
    """Small feedback dialog (used by the no-console 'just works' mode)."""
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk(); r.withdraw()
        (messagebox.showerror if kind == 'error' else messagebox.showinfo)(title, text)
        r.destroy()
    except Exception:
        print(text)


def run_auto(folder, open_browser=True):
    """Silent 'drop-in' mode: build the dashboard for `folder`, open it, report."""
    try:
        out, stats = pipeline.generate(folder)
    except Exception as e:
        _popup('error', "Civ Dashboard — ошибка", str(e))
        return 1
    if open_browser:
        webbrowser.open('file://' + os.path.abspath(out))
    tail = ""
    if stats['skipped_empty'] or stats['errors']:
        tail = "\nПропущено пустых/битых: %d" % (stats['skipped_empty'] + stats['errors'])
    _popup('info', "Civ Dashboard — готово",
           "Дашборд собран: %d игроков.\nФайл: %s%s\nОткрываю в браузере."
           % (stats['players'], out, tail))
    return 0


def main():
    raw = sys.argv[1:]
    if '--version' in raw:
        print("civdash %s" % __version__)
        return 0
    paths = [a for a in raw if not a.startswith('-')]

    # 1) Path(s) passed or a folder dropped onto the exe -> build for that folder.
    target = _resolve_target(paths)
    if target:
        # keep a real console run informative if a console exists
        if sys.stdout and sys.stdout.isatty() and paths:
            class _A:  # minimal shim for run_cli
                pass
            a = _A(); a.folder = target; a.output = None; a.open = ('--open' in raw)
            return run_cli(a)
        return run_auto(target)

    # 2) Double-clicked exe sitting inside a logs folder -> use its own folder.
    if getattr(sys, 'frozen', False):
        exe_dir = os.path.dirname(os.path.abspath(sys.executable))
        if _has_logs(exe_dir):
            return run_auto(exe_dir)

    # 3) Otherwise open the window with a folder picker.
    run_gui()
    return 0


if __name__ == '__main__':
    sys.exit(main())
