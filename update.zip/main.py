#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Civ4Col / We The People — tournament log dashboard.

Run with no arguments  -> graphical window (splash, auto-find or pick folder, build).
Run with a folder path -> command line (batch / scripting).

    CivDashboard.exe                       # GUI
    CivDashboard.exe "C:\\path\\to\\logs"    # CLI
    CivDashboard.exe "C:\\logs" out.html --open
"""
import os
import sys
import argparse
import webbrowser

# Under a PyInstaller --noconsole (--windowed) build, sys.stdout / sys.stderr are
# None. Any print() then raises AttributeError and can crash the GUI when a broken
# log file is skipped (the skip paths print diagnostics). Route writes to a sink so
# print() is always safe, in every mode.
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')

# Make the package importable both from source and from a PyInstaller bundle.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from civdash import pipeline, __version__


# ---------------------------------------------------------------- config (last folder)
def _config_path():
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    d = os.path.join(base, 'CivDashboard')
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        d = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(d, 'config.json')


def load_config():
    import json
    try:
        with open(_config_path(), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg):
    import json
    try:
        with open(_config_path(), 'w', encoding='utf-8') as f:
            json.dump(cfg, f, ensure_ascii=False)
    except Exception:
        pass


# ---------------------------------------------------------------- auto-find log folders
# Все логи начинаются с cp1251-заголовка «Название игры:»; плюс запасные игровые маркеры.
_CIV_HEADER = b'\xcd\xe0\xe7\xe2\xe0\xed\xe8\xe5 \xe8\xe3\xf0\xfb'  # "Название игры" (cp1251)
_CIV_MARKERS = (b'DECLARE WAR', b'CHANGE TURN', b'BUY EUROPE UNIT',
                b'DEATH UNIT', b'GAMESPEED_', b'WORLDSIZE_')


def _looks_like_civ_log(path):
    """True if a .txt file is a Civ4Col log (header or gameplay markers; reads up to 64 KB)."""
    try:
        with open(path, 'rb') as f:
            head = f.read(65536)
    except OSError:
        return False
    if _CIV_HEADER in head[:128]:
        return True
    return any(m in head for m in _CIV_MARKERS)


def _folder_civ_count(folder):
    """Total .txt in folder if at least a couple of them look like Civ logs, else 0.
    Samples up to 60 files (folders mix real logs with network/telemetry .txt)."""
    try:
        files = [f for f in os.listdir(folder) if f.lower().endswith('.txt')]
    except OSError:
        return 0
    if len(files) < 3:
        return 0
    hits = 0
    for f in files[:60]:
        if _looks_like_civ_log(os.path.join(folder, f)):
            hits += 1
            if hits >= 2:
                return len(files)
    return 0


def find_log_folders(extra_first=None, max_hits=8, budget_s=8.0):
    """Scan likely locations for folders full of Civ .txt logs.
    Returns [(path, txt_count)] sorted by count desc. Time- and depth-bounded."""
    import time
    home = os.path.expanduser('~')
    roots = []
    for r in [extra_first,
              os.path.join(home, 'Documents', 'My Games'),
              os.path.join(home, 'OneDrive', 'Documents', 'My Games'),
              os.path.join(home, 'Desktop'),
              os.path.join(home, 'OneDrive', 'Desktop'),
              os.path.join(home, 'OneDrive', 'Рабочий стол'),
              os.path.join(home, 'Downloads')]:
        if r and os.path.isdir(r) and r not in roots:
            roots.append(r)
    deadline = time.time() + budget_s
    found = {}
    for root in roots:
        if time.time() > deadline or len(found) >= max_hits:
            break
        try:
            for dirpath, dirs, files in os.walk(root):
                if time.time() > deadline or len(found) >= max_hits:
                    break
                depth = dirpath[len(root):].count(os.sep)
                if depth >= 4:
                    dirs[:] = []
                    continue
                dirs[:] = [d for d in dirs
                           if not d.startswith('.')
                           and d.lower() not in ('node_modules', '$recycle.bin', 'windows', 'appdata')]
                if sum(1 for f in files if f.lower().endswith('.txt')) >= 3:
                    if dirpath not in found:
                        c = _folder_civ_count(dirpath)
                        if c:
                            found[dirpath] = c
        except Exception:
            pass
    return sorted(found.items(), key=lambda x: -x[1])


# ---------------------------------------------------------------- GUI
def run_gui():
    import threading
    import queue
    import time
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    APPDIR = os.path.dirname(os.path.abspath(__file__))
    cfg = load_config()

    root = tk.Tk()
    root.title("Civ4Col — Дашборд по логам  v%s" % __version__)
    root.geometry("700x470")
    root.minsize(620, 430)

    # ============================ SPLASH / загрузочная страница ============================
    splash = tk.Frame(root, bg="#0f1420")
    splash.place(relx=0, rely=0, relwidth=1, relheight=1)
    root._sp_imgs = []  # keep image refs alive
    splash_dir = os.path.join(APPDIR, 'splash')
    try:
        if os.path.isdir(splash_dir):
            for fn in sorted(os.listdir(splash_dir)):
                if fn.lower().endswith(('.png', '.gif', '.ppm')):
                    try:
                        root._sp_imgs.append(tk.PhotoImage(file=os.path.join(splash_dir, fn)))
                    except Exception:
                        pass
    except OSError:
        pass
    if root._sp_imgs:
        tk.Label(splash, image=root._sp_imgs[0], bg="#0f1420").pack(expand=True, pady=(40, 0))
    else:
        tk.Label(splash, text="◆ CIV DASHBOARD", fg="#e8edf7", bg="#0f1420",
                 font=('Segoe UI', 24, 'bold')).pack(expand=True, pady=(80, 2))
        tk.Label(splash, text="Colonization / We The People — разбор по логам",
                 fg="#9aa7c2", bg="#0f1420", font=('Segoe UI', 11)).pack()
    sp_status = tk.StringVar(value="Загрузка…")
    tk.Label(splash, textvariable=sp_status, fg="#9aa7c2", bg="#0f1420",
             font=('Segoe UI', 10)).pack(pady=(12, 6))
    sp_bar = ttk.Progressbar(splash, mode='indeterminate', length=300)
    sp_bar.pack(pady=(0, 70))
    sp_bar.start(12)

    scan_q = queue.Queue()

    def _bg_scan():
        last = cfg.get('last_folder')
        extra = last if (last and os.path.isdir(last)) else None
        try:
            res = find_log_folders(extra_first=extra)
        except Exception:
            res = []
        scan_q.put(res)

    threading.Thread(target=_bg_scan, daemon=True).start()
    sp_status.set("Ищу папки с логами…")
    t0 = time.time()

    def _poll_scan():
        try:
            found = scan_q.get_nowait()
        except queue.Empty:
            root.after(120, _poll_scan)
            return
        wait = max(0, 900 - int((time.time() - t0) * 1000))  # show splash at least ~0.9s
        root.after(wait, lambda: _build_main(found))

    root.after(200, _poll_scan)

    # ============================ MAIN UI ============================
    def _build_main(found):
        try:
            sp_bar.stop()
        except Exception:
            pass
        splash.destroy()

        state = {'folder': '', 'out': '', 'busy': False}
        q = queue.Queue()
        uq = queue.Queue()

        frm = ttk.Frame(root, padding=18)
        frm.pack(fill='both', expand=True)

        ttk.Label(frm, text="Оценка игроков — Colonization / We The People",
                  font=('Segoe UI', 13, 'bold')).pack(anchor='w')
        ttk.Label(frm, text="Найди папку с логами автоматически или укажи путь вручную, затем «Построить дашборд».",
                  foreground='#555').pack(anchor='w', pady=(2, 12))

        mode = tk.StringVar(value='auto')
        modebar = ttk.Frame(frm)
        modebar.pack(fill='x')
        ttk.Radiobutton(modebar, text="Найти автоматически", variable=mode, value='auto',
                        command=lambda: _apply_mode()).pack(side='left')
        ttk.Radiobutton(modebar, text="Указать вручную", variable=mode, value='manual',
                        command=lambda: _apply_mode()).pack(side='left', padx=(16, 0))

        path_var = tk.StringVar(value="папка не выбрана")
        status_var = tk.StringVar(value="")

        def _select(folder):
            state['folder'] = folder
            path_var.set(folder)
            build_btn.config(state='normal')
            status_var.set("Готово к сборке.")

        # ---- авто ----
        auto_row = ttk.Frame(frm)
        auto_map = {("%s   (%d файлов)" % (p, c)): p for p, c in found}
        auto_combo = ttk.Combobox(auto_row, values=list(auto_map.keys()), state='readonly')
        auto_combo.pack(side='left', fill='x', expand=True)

        def _auto_pick(_=None):
            lbl = auto_combo.get()
            if lbl in auto_map:
                _select(auto_map[lbl])

        auto_combo.bind('<<ComboboxSelected>>', _auto_pick)

        def _rescan():
            rescan_btn.config(state='disabled')
            status_var.set("Ищу папки с логами…")

            def w():
                last = state['folder'] or cfg.get('last_folder')
                extra = last if (last and os.path.isdir(last)) else None
                try:
                    res = find_log_folders(extra_first=extra)
                except Exception:
                    res = []
                q.put(('scan', res))

            threading.Thread(target=w, daemon=True).start()
            root.after(80, pump)

        rescan_btn = ttk.Button(auto_row, text="🔄 Искать заново", command=_rescan)
        rescan_btn.pack(side='left', padx=(8, 0))

        # ---- вручную ----
        man_row = ttk.Frame(frm)
        ttk.Entry(man_row, textvariable=path_var, state='readonly').pack(side='left', fill='x', expand=True)

        def pick():
            init = state['folder'] or cfg.get('last_folder') or ''
            kw = {}
            if os.path.isdir(init):
                kw['initialdir'] = init
            d = filedialog.askdirectory(title="Папка с логами", **kw)
            if d:
                _select(d)

        ttk.Button(man_row, text="📁 Выбрать папку…", command=pick).pack(side='left', padx=(8, 0))

        def _apply_mode():
            if mode.get() == 'auto':
                man_row.pack_forget()
                auto_row.pack(fill='x', pady=(10, 0))
            else:
                auto_row.pack_forget()
                man_row.pack(fill='x', pady=(10, 0))

        _apply_mode()

        cur_lbl = ttk.Label(frm, textvariable=path_var, foreground='#2c5', wraplength=640)
        cur_lbl.pack(anchor='w', pady=(10, 0))

        pbar = ttk.Progressbar(frm, mode='determinate', maximum=100)
        pbar.pack(fill='x', pady=(14, 6))
        ttk.Label(frm, textvariable=status_var, foreground='#333').pack(anchor='w')

        btns = ttk.Frame(frm)
        btns.pack(fill='x', pady=(16, 0))

        # ---- build ----
        def worker(folder):
            def prog(done, total, fname):
                q.put(('progress', done, total, fname))
            try:
                out, stats = pipeline.generate(folder, progress=prog)
                q.put(('done', out, stats))
            except Exception as e:
                q.put(('error', str(e)))

        def start_build():
            if state['busy'] or not state['folder']:
                return
            state['busy'] = True
            build_btn.config(state='disabled')
            open_btn.config(state='disabled')
            pbar.config(value=0)
            status_var.set("Читаю логи…")
            cfg['last_folder'] = state['folder']
            save_config(cfg)
            threading.Thread(target=worker, args=(state['folder'],), daemon=True).start()
            root.after(80, pump)

        def open_result():
            if state['out']:
                webbrowser.open('file://' + os.path.abspath(state['out']))

        def pump():
            try:
                while True:
                    msg = q.get_nowait()
                    tag = msg[0]
                    if tag == 'progress':
                        _, done, total, fname = msg
                        pbar.config(value=(done / total * 100) if total else 100)
                        status_var.set("Разбор логов: %d / %d   %s" % (done, total, fname[:36]))
                    elif tag == 'done':
                        _, out, stats = msg
                        state['out'] = out
                        state['busy'] = False
                        pbar.config(value=100)
                        status_var.set("Готово: %d игроков  ·  %.1f МБ"
                                       % (stats['players'], stats['bytes'] / 1024 / 1024))
                        build_btn.config(state='normal')
                        open_btn.config(state='normal')
                        if stats.get('errors') or stats.get('skipped_empty'):
                            status_var.set(status_var.get() +
                                           "  (пропущено: %d, ошибок: %d)"
                                           % (stats['skipped_empty'], stats['errors']))
                        return
                    elif tag == 'error':
                        state['busy'] = False
                        build_btn.config(state='normal')
                        status_var.set("Ошибка.")
                        messagebox.showerror("Ошибка", msg[1])
                        return
                    elif tag == 'scan':
                        res = msg[1]
                        auto_map.clear()
                        auto_map.update({("%s   (%d файлов)" % (p, c)): p for p, c in res})
                        auto_combo.config(values=list(auto_map.keys()))
                        rescan_btn.config(state='normal')
                        if res:
                            auto_combo.current(0)
                            _auto_pick()
                            status_var.set("Найдено папок: %d." % len(res))
                        else:
                            status_var.set("Папки с логами не найдены — укажи вручную.")
                        return
            except queue.Empty:
                pass
            root.after(80, pump)

        build_btn = ttk.Button(btns, text="Построить дашборд", command=start_build, state='disabled')
        build_btn.pack(side='left')
        open_btn = ttk.Button(btns, text="Открыть дашборд", command=open_result, state='disabled')
        open_btn.pack(side='left', padx=(8, 0))

        # ---- online update ----
        def check_update():
            if state['busy']:
                return
            upd_btn.config(state='disabled')
            status_var.set("Проверяю обновления…")

            def work():
                try:
                    from civdash import updater
                    man = updater.fetch_manifest()
                    remote = man.get('version', '0')
                    if not updater.is_newer(remote, __version__):
                        uq.put(('none', remote))
                        return
                    updater.apply_update(APPDIR, man)
                    uq.put(('udone', remote, man.get('notes', '')))
                except Exception as e:
                    uq.put(('uerror', str(e)))

            threading.Thread(target=work, daemon=True).start()
            root.after(120, upd_pump)

        def upd_pump():
            try:
                while True:
                    m = uq.get_nowait()
                    if m[0] == 'none':
                        status_var.set("У вас последняя версия v%s." % m[1])
                        upd_btn.config(state='normal')
                        messagebox.showinfo("Обновление", "У вас уже последняя версия (v%s)." % m[1])
                        return
                    elif m[0] == 'udone':
                        status_var.set("Обновлено до v%s — перезапустите программу." % m[1])
                        upd_btn.config(state='normal')
                        messagebox.showinfo(
                            "Обновление установлено",
                            "Установлена версия v%s.\n\nЧто нового:\n%s\n\nЗакройте и откройте программу "
                            "заново, чтобы изменения вступили в силу." % (m[1], m[2] or '—'))
                        return
                    elif m[0] == 'uerror':
                        status_var.set("Не удалось обновиться.")
                        upd_btn.config(state='normal')
                        messagebox.showerror(
                            "Обновление",
                            "Не получилось проверить/скачать обновление:\n%s\n\n"
                            "Проверьте интернет и попробуйте позже." % m[1])
                        return
            except queue.Empty:
                pass
            root.after(120, upd_pump)

        upd_btn = ttk.Button(btns, text="Обновить программу", command=check_update)
        upd_btn.pack(side='right')

        ttk.Label(frm, text="Дашборд сохранится файлом dashboard.html в той же папке с логами.",
                  foreground='#888').pack(anchor='w', side='bottom')

        # ---- preselect: last folder or best auto result ----
        pre = cfg.get('last_folder')
        if found:
            sel = 0
            if pre:
                for i, (p, c) in enumerate(found):
                    if os.path.normcase(os.path.abspath(p)) == os.path.normcase(os.path.abspath(pre)):
                        sel = i
                        break
            auto_combo.current(sel)
            _auto_pick()
            status_var.set("Найдено папок: %d. Проверь выбор и жми «Построить»." % len(found))
        elif pre and os.path.isdir(pre) and _has_logs(pre):
            mode.set('manual')
            _apply_mode()
            _select(pre)
            status_var.set("Последняя папка подставлена. Жми «Построить» или выбери другую.")
        else:
            mode.set('manual')
            _apply_mode()
            status_var.set("Папки с логами не найдены — укажи путь вручную.")

    root.mainloop()


def _has_logs(folder):
    """True if the folder directly contains at least one *.txt."""
    try:
        return any(f.lower().endswith('.txt') for f in os.listdir(folder))
    except OSError:
        return False


def _resolve_target(paths):
    """From dropped/passed paths pick the logs folder: a dropped folder as-is,
    or the parent folder of dropped file(s)."""
    for p in paths:
        if p and os.path.isdir(p):
            return p
    for p in paths:
        if p and os.path.isfile(p):
            return os.path.dirname(os.path.abspath(p))
    return None


def _popup(kind, title, text):
    """Small feedback dialog (used by the no-console 'just works' mode)."""
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        (messagebox.showerror if kind == 'error' else messagebox.showinfo)(title, text)
        r.destroy()
    except Exception:
        print(text)


def run_cli(args):
    def prog(done, total, fname):
        pct = int(done / total * 100) if total else 100
        sys.stdout.write("\r  [%3d%%] %d/%d  %-40s" % (pct, done, total, fname[:40]))
        sys.stdout.flush()

    print("Civ Dashboard v%s" % __version__)
    print("Папка логов: %s" % args.folder)
    out, stats = pipeline.generate(args.folder, args.output, progress=prog)
    print()
    print("Готово: %s" % out)
    print("  игроков: %d   (старый формат: %d, новый: %d, пропущено пустых: %d, ошибок: %d)"
          % (stats['players'], stats['legacy'], stats['ideal'],
             stats['skipped_empty'], stats['errors']))
    print("  размер: %.1f МБ" % (stats['bytes'] / 1024 / 1024))
    if args.open:
        webbrowser.open('file://' + os.path.abspath(out))
    return 0


def run_auto(folder, open_browser=True):
    """Silent 'drop-in' mode: build the dashboard for `folder`, open it, report."""
    try:
        out, stats = pipeline.generate(folder)
    except Exception as e:
        _popup('error', "Civ Dashboard — ошибка", str(e))
        return 1
    if open_browser:
        webbrowser.open('file://' + os.path.abspath(out))
    tail = ""
    if stats['skipped_empty'] or stats['errors']:
        tail = "\nПропущено пустых/битых: %d" % (stats['skipped_empty'] + stats['errors'])
    _popup('info', "Civ Dashboard — готово",
           "Дашборд собран: %d игроков.\nФайл: %s%s\nОткрываю в браузере."
           % (stats['players'], out, tail))
    return 0


def main():
    raw = sys.argv[1:]
    if '--version' in raw:
        print("civdash %s" % __version__)
        return 0
    paths = [a for a in raw if not a.startswith('-')]

    # 1) Path(s) passed or a folder dropped onto the exe -> build for that folder.
    target = _resolve_target(paths)
    if target:
        if sys.stdout and sys.stdout.isatty() and paths:
            class _A:
                pass
            a = _A(); a.folder = target; a.output = None; a.open = ('--open' in raw)
            return run_cli(a)
        return run_auto(target)

    # 2) Double-clicked exe sitting inside a logs folder -> use its own folder.
    if getattr(sys, 'frozen', False):
        exe_dir = os.path.dirname(os.path.abspath(sys.executable))
        if _has_logs(exe_dir):
            return run_auto(exe_dir)

    # 3) Otherwise open the window (splash -> auto-find / manual -> build).
    run_gui()
    return 0


if __name__ == '__main__':
    sys.exit(main())
