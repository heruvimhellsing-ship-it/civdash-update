#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Civ4Col / We The People — tournament log dashboard.

Run with no arguments  -> graphical window (splash, auto-find or pick folder, build).
Run with a folder path -> command line (batch / scripting).

    CivDashboard.exe                       # GUI
    CivDashboard.exe "C:\\path\\to\\logs"    # CLI
    CivDashboard.exe "C:\\logs" out.html --open
"""
import os
import sys
import argparse
import webbrowser

# Under a PyInstaller --noconsole (--windowed) build, sys.stdout / sys.stderr are
# None. Any print() then raises AttributeError and can crash the GUI when a broken
# log file is skipped (the skip paths print diagnostics). Route writes to a sink so
# print() is always safe, in every mode.
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')

# Make the package importable both from source and from a PyInstaller bundle.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from civdash import pipeline, __version__


# ---------------------------------------------------------------- open dashboard in its own window
def _find_browsers():
    """Chromium-based browsers already installed on this Windows (Edge всегда есть)."""
    import shutil
    pf = os.environ.get('ProgramFiles', r'C:\Program Files')
    pfx = os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')
    la = os.environ.get('LOCALAPPDATA', '')
    cands = [
        os.path.join(pf, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
        os.path.join(pfx, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
        os.path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'),
        os.path.join(pfx, 'Google', 'Chrome', 'Application', 'chrome.exe'),
        os.path.join(la, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    ]
    for name in ('msedge', 'chrome', 'chromium', 'brave'):
        w = shutil.which(name)
        if w:
            cands.append(w)
    seen, out = set(), []
    for c in cands:
        if c and os.path.exists(c) and c.lower() not in seen:
            seen.add(c.lower())
            out.append(c)
    return out


def _launch_dashboard(path):
    """Открыть готовый дашборд в отдельном окне приложения (Chromium в режиме --app,
    без вкладок и адресной строки). Если такого нет — обычный браузер."""
    import subprocess
    try:
        import pathlib
        uri = pathlib.Path(os.path.abspath(path)).as_uri()
    except Exception:
        uri = 'file://' + os.path.abspath(path)
    # размер монитора
    sw = sh = None
    try:
        import ctypes
        u = ctypes.windll.user32
        u.SetProcessDPIAware()
        sw = u.GetSystemMetrics(0); sh = u.GetSystemMetrics(1)
    except Exception:
        sw = sh = None
    # отдельный профиль -> запускается СВОЙ процесс движка, который слушает флаги
    # (иначе уже открытый Chrome игнорирует размер и окно выходит в пол-экрана)
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    prof = os.path.join(base, 'CivDashboard', 'viewer')
    try:
        os.makedirs(prof, exist_ok=True)
    except OSError:
        pass
    # --start-fullscreen: во весь экран, без заголовка/кнопок браузера (выглядит как приложение, не браузер).
    # Выход — F11 или Alt+F4.
    flags = ['--app=' + uri, '--user-data-dir=' + prof,
             '--no-first-run', '--no-default-browser-check',
             '--start-fullscreen', '--start-maximized']
    if sw and sh:
        flags += ['--window-position=0,0', '--window-size=%d,%d' % (sw, sh)]
    for exe in _find_browsers():
        try:
            subprocess.Popen([exe] + flags)
            return True
        except Exception:
            pass
    try:
        webbrowser.open(uri)
        return True
    except Exception:
        return False


# ---------------------------------------------------------------- config (last folder)
def _config_path():
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    d = os.path.join(base, 'CivDashboard')
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        d = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(d, 'config.json')


def load_config():
    import json
    try:
        with open(_config_path(), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg):
    import json
    try:
        with open(_config_path(), 'w', encoding='utf-8') as f:
            json.dump(cfg, f, ensure_ascii=False)
    except Exception:
        pass


# ---------------------------------------------------------------- auto-find log folders
# Все логи начинаются с cp1251-заголовка «Название игры:»; плюс запасные игровые маркеры.
_CIV_HEADER = b'\xcd\xe0\xe7\xe2\xe0\xed\xe8\xe5 \xe8\xe3\xf0\xfb'  # "Название игры" (cp1251)
_CIV_MARKERS = (b'DECLARE WAR', b'CHANGE TURN', b'BUY EUROPE UNIT',
                b'DEATH UNIT', b'GAMESPEED_', b'WORLDSIZE_')


def _looks_like_civ_log(path):
    """True if a .txt file is a Civ4Col log (header or gameplay markers; reads up to 64 KB)."""
    try:
        with open(path, 'rb') as f:
            head = f.read(65536)
    except OSError:
        return False
    if _CIV_HEADER in head[:128]:
        return True
    return any(m in head for m in _CIV_MARKERS)


def _folder_civ_count(folder):
    """Total .txt in folder if at least a couple of them look like Civ logs, else 0.
    Samples up to 60 files (folders mix real logs with network/telemetry .txt)."""
    try:
        files = [f for f in os.listdir(folder) if f.lower().endswith('.txt')]
    except OSError:
        return 0
    if len(files) < 3:
        return 0
    hits = 0
    for f in files[:60]:
        if _looks_like_civ_log(os.path.join(folder, f)):
            hits += 1
            if hits >= 2:
                return len(files)
    return 0


def find_log_folders(extra_first=None, max_hits=8, budget_s=8.0):
    """Scan likely locations for folders full of Civ .txt logs.
    Returns [(path, txt_count)] sorted by count desc. Time- and depth-bounded."""
    import time
    home = os.path.expanduser('~')
    roots = []
    for r in [extra_first,
              os.path.join(home, 'Documents', 'My Games'),
              os.path.join(home, 'OneDrive', 'Documents', 'My Games'),
              os.path.join(home, 'Desktop'),
              os.path.join(home, 'OneDrive', 'Desktop'),
              os.path.join(home, 'OneDrive', 'Рабочий стол'),
              os.path.join(home, 'Downloads')]:
        if r and os.path.isdir(r) and r not in roots:
            roots.append(r)
    deadline = time.time() + budget_s
    found = {}
    for root in roots:
        if time.time() > deadline or len(found) >= max_hits:
            break
        try:
            for dirpath, dirs, files in os.walk(root):
                if time.time() > deadline or len(found) >= max_hits:
                    break
                depth = dirpath[len(root):].count(os.sep)
                if depth >= 4:
                    dirs[:] = []
                    continue
                dirs[:] = [d for d in dirs
                           if not d.startswith('.')
                           and d.lower() not in ('node_modules', '$recycle.bin', 'windows', 'appdata')]
                if sum(1 for f in files if f.lower().endswith('.txt')) >= 3:
                    if dirpath not in found:
                        c = _folder_civ_count(dirpath)
                        if c:
                            found[dirpath] = c
        except Exception:
            pass
    return sorted(found.items(), key=lambda x: -x[1])


# ---------------------------------------------------------------- GUI
def run_gui():
    """Единый тёмный загрузочный экран: авто-обновление -> поиск папки -> сборка -> открытие.
    Тумблер «Указать вручную» (по умолчанию — автомат)."""
    import threading
    import queue
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    APPDIR = os.path.dirname(os.path.abspath(__file__))
    cfg = load_config()

    BG, PANEL, FG, MUT, ACC = "#0e0b07", "#241a10", "#f2ead6", "#b9ab8a", "#d9b45a"
    CARD = "#141009"
    # один экземпляр: если уже запущено — не открываем второе поверх
    import socket
    try:
        _lock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        _lock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
        _lock.bind(("127.0.0.1", 49517))
        _lock.listen(1)
    except OSError:
        return  # другой экземпляр уже работает

    root = tk.Tk()
    root._lock = _lock
    root.title("Civ Dashboard  v%s" % __version__)
    root.attributes('-fullscreen', True)   # во весь монитор
    root.configure(bg=BG)
    root.bind('<Escape>', lambda e: root.destroy())
    try:
        SW = root.winfo_screenwidth(); SH = root.winfo_screenheight()
    except Exception:
        SW, SH = 1366, 768
    OX = max(0, (SW - 720) // 2); OY = max(0, (SH - 520) // 2)

    style = ttk.Style()
    try:
        style.theme_use('clam')
    except Exception:
        pass
    style.configure('Dark.Horizontal.TProgressbar', background=ACC, troughcolor='#2a2114', borderwidth=0, thickness=8)
    style.configure('Dark.TButton', background='#312616', foreground=FG, borderwidth=1, focuscolor=BG, padding=7)
    style.map('Dark.TButton', background=[('active', '#3f3120'), ('disabled', '#211a10')],
              foreground=[('disabled', '#7a6f57')])
    style.configure('Big.TButton', background=ACC, foreground='#221706', borderwidth=0,
                    focuscolor=ACC, padding=(22, 13), font=('Segoe UI', 12, 'bold'))
    style.map('Big.TButton', background=[('active', '#e9c877')])

    # фон: ночная гавань из Colonization + полупрозрачная панель (запечена в PNG)
    root._bg_img = None
    try:
        _bgp = os.path.join(APPDIR, 'civdash', 'resources', 'splash_bg.png')
        if os.path.exists(_bgp):
            root._bg_img = tk.PhotoImage(file=_bgp)
    except Exception:
        root._bg_img = None

    CX = OX + 360
    canvas = tk.Canvas(root, width=SW, height=SH, highlightthickness=0, bd=0, bg=BG)
    canvas.pack(fill='both', expand=True)
    if root._bg_img is not None:
        # большая подложка (гавань) заполняет монитор; панель запечена в её центре
        canvas.create_image(OX + 360, OY + 260, anchor='center', image=root._bg_img)

    canvas.create_text(CX, OY+152, text="\u25c6 CIV DASHBOARD", fill=ACC,
                       font=('Segoe UI', 24, 'bold'))

    status = tk.StringVar(value="\u0417\u0430\u043f\u0443\u0441\u043a\u2026")
    _st = canvas.create_text(CX, OY+204, text=status.get(), fill=FG, font=('Segoe UI', 12))
    status.trace_add('write', lambda *a: canvas.itemconfigure(_st, text=status.get()))

    bar = ttk.Progressbar(canvas, style='Dark.Horizontal.TProgressbar', mode='determinate',
                          maximum=100, length=380)
    canvas.create_window(CX, OY+240, window=bar)

    sub = tk.StringVar(value="")
    _sb = canvas.create_text(CX, OY+266, text="", fill=MUT, font=('Segoe UI', 9))
    sub.trace_add('write', lambda *a: canvas.itemconfigure(_sb, text=sub.get()))

    # выбранная папка (видна только в ручном режиме)
    folder_var = tk.StringVar(value="")
    _fld = canvas.create_text(CX, OY+290, text="", fill=ACC, font=('Segoe UI', 9),
                              width=470, justify='center', state='hidden')
    folder_var.trace_add('write', lambda *a: canvas.itemconfigure(_fld, text=folder_var.get()))

    def _show_folder():
        canvas.itemconfigure(_fld, state='normal')

    # крупная кнопка ручного выбора папки
    manual_btn = ttk.Button(canvas, text="\U0001F4C1 \u0423\u043a\u0430\u0437\u0430\u0442\u044c \u043f\u0430\u043f\u043a\u0443 \u0432\u0440\u0443\u0447\u043d\u0443\u044e",
                            style='Big.TButton', command=lambda: _manual())
    canvas.create_window(CX, OY+328, window=manual_btn)

    # «Открыть дашборд» — только в ручном режиме (в авто открывается сам)
    open_btn = ttk.Button(canvas, text="\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0434\u0430\u0448\u0431\u043e\u0440\u0434",
                          style='Dark.TButton', state='disabled', command=lambda: _open())
    _open_win = canvas.create_window(CX, OY+368, window=open_btn, state='hidden')

    def _show_open():
        canvas.itemconfigure(_open_win, state='normal')

    # строка версии (всегда видна)
    ver_var = tk.StringVar(value="\u0432\u0435\u0440\u0441\u0438\u044f %s" % __version__)
    _vr = canvas.create_text(CX, OY+400, text=ver_var.get(), fill=MUT, font=('Segoe UI', 9))
    ver_var.trace_add('write', lambda *a: canvas.itemconfigure(_vr, text=ver_var.get()))

    state = {'folder': '', 'out': '', 'busy': False, 'cancel_auto': False, 'build_id': 0, 'manual': False}
    q = queue.Queue()

    def _bar(v, indet=False):
        if indet:
            bar.config(mode='indeterminate')
            bar.start(12)
        else:
            try:
                bar.stop()
            except Exception:
                pass
            bar.config(mode='determinate', value=v)

    def _open():
        if state['out']:
            _launch_dashboard(state['out'])

    def _pick():
        init = state['folder'] or cfg.get('last_folder') or ''
        kw = {'initialdir': init} if os.path.isdir(init) else {}
        d = filedialog.askdirectory(title="\u041f\u0430\u043f\u043a\u0430 \u0441 \u043b\u043e\u0433\u0430\u043c\u0438", **kw)
        if d:
            state['folder'] = d
            folder_var.set(d)
            _show_folder()
            _start_build(d)

    def _manual():
        # ручной режим: отменяем авто-сборку/поиск и открываем выбор папки
        state['cancel_auto'] = True
        state['build_id'] += 1
        state['busy'] = False
        try:
            bar.stop()
        except Exception:
            pass
        _bar(0)
        state['manual'] = True
        _show_open()
        open_btn.config(state=('normal' if state['out'] else 'disabled'))
        _pick()

    def _start_build(folder):
        if state['busy']:
            return
        state['busy'] = True
        state['build_id'] += 1
        bid = state['build_id']
        if state.get('manual'):
            open_btn.config(state='disabled')
        cfg['last_folder'] = folder
        save_config(cfg)
        status.set("\u0421\u0442\u0440\u043e\u044e \u0434\u0430\u0448\u0431\u043e\u0440\u0434\u2026")
        sub.set(folder)
        _bar(0)

        def w():
            def prog(done, total, fn):
                q.put(('prog', done, total, fn, bid))
            try:
                out, stats = pipeline.generate(folder, progress=prog)
                q.put(('built', out, stats, bid))
            except Exception as e:
                q.put(('berr', str(e), bid))

        threading.Thread(target=w, daemon=True).start()
        root.after(80, pump)

    def _run_auto():
        if state['busy']:
            return
        state['cancel_auto'] = False
        status.set("\u041f\u0440\u043e\u0432\u0435\u0440\u044f\u044e \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f\u2026")
        sub.set("\u0442\u0435\u043a\u0443\u0449\u0430\u044f \u0432\u0435\u0440\u0441\u0438\u044f: v%s" % __version__)
        _bar(0, indet=True)

        def w():
            try:
                from civdash import updater
                man_j = updater.fetch_manifest()
                remote = man_j.get('version', '0')
                if updater.is_newer(remote, __version__):
                    q.put(('status', "\u0421\u043a\u0430\u0447\u0438\u0432\u0430\u044e \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 v%s\u2026" % remote))
                    def _uprog(done, total, name):
                        q.put(('uprog', done, total, remote))
                    updater.apply_update(APPDIR, man_j, progress=_uprog)
                    q.put(('upded', __version__, remote))
                else:
                    q.put(('uptodate', __version__))
            except Exception:
                q.put(('upfail', __version__))
            if state['cancel_auto']:
                q.put(('acancel',)); return
            q.put(('ind',))
            q.put(('status', "\u0418\u0449\u0443 \u043f\u0430\u043f\u043a\u0443 \u0441 \u043b\u043e\u0433\u0430\u043c\u0438\u2026"))
            last = cfg.get('last_folder')
            extra = last if (last and os.path.isdir(last)) else None
            try:
                found = find_log_folders(extra_first=extra)
            except Exception:
                found = []
            if state['cancel_auto']:
                q.put(('acancel',)); return
            q.put(('found', found))

        threading.Thread(target=w, daemon=True).start()
        root.after(100, pump)

    def pump():
        try:
            while True:
                m = q.get_nowait()
                t = m[0]
                if t == 'status':
                    status.set(m[1])
                elif t == 'uprog':
                    _, done, total, remote = m
                    _bar((done / total * 100) if total else 100)
                    sub.set("\u0441\u043a\u0430\u0447\u0438\u0432\u0430\u043d\u0438\u0435 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f v%s: %d / %d \u0444\u0430\u0439\u043b\u043e\u0432" % (remote, done, total))
                elif t == 'upded':
                    _, old, remote = m
                    ver_var.set("\u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u043e: v%s \u2192 v%s" % (old, remote))
                    sub.set("\u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e \u2713")
                elif t == 'uptodate':
                    ver_var.set("\u0432\u0435\u0440\u0441\u0438\u044f %s \u00b7 \u0430\u043a\u0442\u0443\u0430\u043b\u044c\u043d\u0430\u044f \u2713" % m[1])
                elif t == 'upfail':
                    ver_var.set("\u0432\u0435\u0440\u0441\u0438\u044f %s \u00b7 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b" % m[1])
                elif t == 'ind':
                    _bar(0, indet=True)
                elif t == 'acancel':
                    return
                elif t == 'found':
                    found = m[1]
                    if state['cancel_auto']:
                        return
                    if found:
                        state['folder'] = found[0][0]
                        folder_var.set(state['folder'])
                        _bar(0)
                        _start_build(found[0][0])
                    else:
                        _bar(0)
                        status.set("\u041f\u0430\u043f\u043a\u0430 \u0441 \u043b\u043e\u0433\u0430\u043c\u0438 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u0430 \u2014 \u043d\u0430\u0436\u043c\u0438 \u00ab\u0423\u043a\u0430\u0437\u0430\u0442\u044c \u043f\u0430\u043f\u043a\u0443 \u0432\u0440\u0443\u0447\u043d\u0443\u044e\u00bb.")
                    return
                elif t == 'prog':
                    _, done, total, fn, bid = m
                    if bid != state['build_id']:
                        continue
                    _bar((done / total * 100) if total else 100)
                    sub.set("\u043b\u043e\u0433\u043e\u0432: %d / %d" % (done, total))
                elif t == 'built':
                    _, out, stats, bid = m
                    if bid != state['build_id']:
                        continue
                    state['out'] = out
                    state['busy'] = False
                    _bar(100)
                    status.set("\u0413\u043e\u0442\u043e\u0432\u043e: %d \u0438\u0433\u0440\u043e\u043a\u043e\u0432. \u041e\u0442\u043a\u0440\u044b\u0432\u0430\u044e\u2026" % stats['players'])
                    sub.set("%.1f \u041c\u0411" % (stats['bytes'] / 1024 / 1024))
                    if state.get('manual'):
                        open_btn.config(state='normal')
                    _launch_dashboard(out)
                    if not state.get('manual'):
                        # авто-режим: дашборд открыт — закрываем загрузочное окно
                        root.after(1400, root.destroy)
                    return
                elif t == 'berr':
                    _, err, bid = m
                    if bid != state['build_id']:
                        continue
                    state['busy'] = False
                    _bar(0)
                    status.set("\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0440\u0438 \u0441\u0431\u043e\u0440\u043a\u0435.")
                    messagebox.showerror("\u041e\u0448\u0438\u0431\u043a\u0430", err)
                    return
        except queue.Empty:
            pass
        root.after(100, pump)

    root.after(200, _run_auto)
    root.mainloop()


def _has_logs(folder):
    """True if the folder directly contains at least one *.txt."""
    try:
        return any(f.lower().endswith('.txt') for f in os.listdir(folder))
    except OSError:
        return False


def _resolve_target(paths):
    """From dropped/passed paths pick the logs folder: a dropped folder as-is,
    or the parent folder of dropped file(s)."""
    for p in paths:
        if p and os.path.isdir(p):
            return p
    for p in paths:
        if p and os.path.isfile(p):
            return os.path.dirname(os.path.abspath(p))
    return None


def _popup(kind, title, text):
    """Small feedback dialog (used by the no-console 'just works' mode)."""
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        (messagebox.showerror if kind == 'error' else messagebox.showinfo)(title, text)
        r.destroy()
    except Exception:
        print(text)


def run_cli(args):
    def prog(done, total, fname):
        pct = int(done / total * 100) if total else 100
        sys.stdout.write("\r  [%3d%%] %d/%d  %-40s" % (pct, done, total, fname[:40]))
        sys.stdout.flush()

    print("Civ Dashboard v%s" % __version__)
    print("Папка логов: %s" % args.folder)
    out, stats = pipeline.generate(args.folder, args.output, progress=prog)
    print()
    print("Готово: %s" % out)
    print("  игроков: %d   (старый формат: %d, новый: %d, пропущено пустых: %d, ошибок: %d)"
          % (stats['players'], stats['legacy'], stats['ideal'],
             stats['skipped_empty'], stats['errors']))
    print("  размер: %.1f МБ" % (stats['bytes'] / 1024 / 1024))
    if args.open:
        _launch_dashboard(out)
    return 0


def run_auto(folder, open_browser=True):
    """Silent 'drop-in' mode: build the dashboard for `folder`, open it, report."""
    try:
        out, stats = pipeline.generate(folder)
    except Exception as e:
        _popup('error', "Civ Dashboard — ошибка", str(e))
        return 1
    if open_browser:
        _launch_dashboard(out)
    tail = ""
    if stats['skipped_empty'] or stats['errors']:
        tail = "\nПропущено пустых/битых: %d" % (stats['skipped_empty'] + stats['errors'])
    _popup('info', "Civ Dashboard — готово",
           "Дашборд собран: %d игроков.\nФайл: %s%s\nОткрываю в браузере."
           % (stats['players'], out, tail))
    return 0


def main():
    raw = sys.argv[1:]
    if '--version' in raw:
        print("civdash %s" % __version__)
        return 0
    paths = [a for a in raw if not a.startswith('-')]

    # 1) Path(s) passed or a folder dropped onto the exe -> build for that folder.
    target = _resolve_target(paths)
    if target:
        if sys.stdout and sys.stdout.isatty() and paths:
            class _A:
                pass
            a = _A(); a.folder = target; a.output = None; a.open = ('--open' in raw)
            return run_cli(a)
        return run_auto(target)

    # 2) Double-clicked exe sitting inside a logs folder -> use its own folder.
    if getattr(sys, 'frozen', False):
        exe_dir = os.path.dirname(os.path.abspath(sys.executable))
        if _has_logs(exe_dir):
            return run_auto(exe_dir)

    # 3) Otherwise open the window (splash -> auto-find / manual -> build).
    run_gui()
    return 0


if __name__ == '__main__':
    sys.exit(main())
