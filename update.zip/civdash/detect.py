#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Per-file format detection and dispatch.

A folder may mix legacy (cp1251 tournament) and new ideal (UTF-8 spec) logs.
Each file is sniffed independently and sent to the matching parser; both emit
the same player-dict schema, so results merge into one cohort.
"""
import os, glob, re
from . import parse_legacy, parse_ideal


def _is_network_log(p):
    """Сетевые/мультиплеерные логи (MPLog…, network…) — неполные копии тех же партий."""
    return bool(re.search(r'mplog|network', (p.get('file') or ''), re.I))


def _completeness(p):
    """Насколько запись полна — по ней выбираем, какую копию партии оставить."""
    return (0 if _is_network_log(p) else 1,      # обычный лог полнее сетевого
            p.get('tier') or 0,                   # защитил > объявил > не объявлял
            1 if p.get('king_army') is not None else 0,  # есть данные по обороне
            1 if p.get('rev_outcome') == 'won' else 0)


def _dedup_games(players):
    """Одна и та же партия может попасть в несколько логов (обычный + сетевой MPLog).
    Схлопываем по (игрок, год начала, год конца), оставляя самую полную запись.
    Порядок первого появления партии сохраняем."""
    order = []
    groups = {}
    for p in players:
        k = (p.get('player'), p.get('year_start'), p.get('year_end'))
        if k not in groups:
            groups[k] = []
            order.append(k)
        groups[k].append(p)
    return [max(groups[k], key=_completeness) for k in order]


def _sniff(path):
    """Return 'ideal' or 'legacy' by peeking at the file head."""
    try:
        raw = open(path, 'rb').read(6000)
    except OSError:
        return 'legacy'
    head = raw.decode('utf-8', 'replace')
    if parse_ideal.is_ideal(head):
        return 'ideal'
    return 'legacy'


def parse_folder(src, progress=None):
    """Parse every *.txt in src, auto-detecting format per file.
    Returns (players, stats) where stats summarises what happened."""
    files = sorted(glob.glob(os.path.join(src, "*.txt")))
    total = len(files)
    players = []
    stats = {'files': total, 'legacy': 0, 'ideal': 0, 'ok': 0, 'skipped_empty': 0, 'errors': 0}
    for i, f in enumerate(files):
        fname = os.path.basename(f)
        try:
            if os.path.getsize(f) < 500:
                stats['skipped_empty'] += 1
            else:
                kind = _sniff(f)
                if kind == 'ideal':
                    text = open(f, 'rb').read().decode('utf-8', 'replace')
                    r = parse_ideal.parse_text(text, fname)
                    stats['ideal'] += 1
                else:
                    r = parse_legacy.parse_file(f)
                    r = parse_legacy._trim(r)
                    stats['legacy'] += 1
                if r and r.get('turns', 0) >= 1:
                    players.append(r)
                    stats['ok'] += 1
                else:
                    stats['skipped_empty'] += 1
        except Exception as e:
            stats['errors'] += 1
            print("skip", fname, repr(e))
        if progress:
            progress(i + 1, total, fname)
    before = len(players)
    players = _dedup_games(players)
    stats['dedup_removed'] = before - len(players)
    players.sort(key=lambda x: -x.get('turns', 0))
    return players, stats
