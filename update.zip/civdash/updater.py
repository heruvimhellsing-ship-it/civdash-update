#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Онлайн-обновление программы из публичного GitHub-репозитория.

В репозитории лежат всего два файла: version.json (номер версии + что нового)
и update.zip (файлы кода программы). Скачивается ТОЛЬКО код; логи, данные игроков
и собранные дашборды никуда не отправляются и остаются на компьютере.
"""
import os
import io
import ssl
import json
import time
import zipfile
import tempfile
import urllib.request

REPO = "heruvimhellsing-ship-it/civdash-update"
BRANCH = "main"
BASE = "https://raw.githubusercontent.com/%s/%s/" % (REPO, BRANCH)


def _ctx():
    try:
        return ssl.create_default_context()
    except Exception:
        return None


def _get(rel, timeout=40):
    url = BASE + rel + ("&" if "?" in rel else "?") + "_=" + str(int(time.time()))
    req = urllib.request.Request(url, headers={"User-Agent": "CivDashboard-Updater"})
    return urllib.request.urlopen(req, timeout=timeout, context=_ctx()).read()


def _ver_tuple(s):
    out = []
    for part in str(s).split("."):
        try:
            out.append(int(part))
        except ValueError:
            out.append(0)
    return tuple(out)


def is_newer(remote, current):
    return _ver_tuple(remote) > _ver_tuple(current)


def fetch_manifest():
    """Читает version.json из репозитория. Кидает исключение при проблемах с сетью."""
    return json.loads(_get("version.json").decode("utf-8"))


def _safe(base_dir, member):
    """Защита от выхода за пределы папки приложения (path traversal)."""
    dst = os.path.normpath(os.path.join(base_dir, *member.split("/")))
    if not dst.startswith(os.path.normpath(base_dir) + os.sep) and dst != os.path.normpath(base_dir):
        return None
    return dst


def apply_update(base_dir, manifest, progress=None):
    """Скачивает update.zip и раскладывает файлы поверх приложения (атомарно).
    base_dir — папка, где лежит main.py (корень приложения)."""
    zip_rel = manifest.get("zip", "update.zip")
    data = _get(zip_rel)
    zf = zipfile.ZipFile(io.BytesIO(data))
    members = [m for m in zf.namelist() if not m.endswith("/")]
    total = len(members)
    done = 0
    for m in members:
        dst = _safe(base_dir, m)
        if dst is None:
            continue
        d = os.path.dirname(dst)
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        content = zf.read(m)
        fd, tmp = tempfile.mkstemp(dir=d or None, suffix=".new")
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(content)
            os.replace(tmp, dst)
        finally:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
        done += 1
        if progress:
            progress(done, total, m)
    return done
