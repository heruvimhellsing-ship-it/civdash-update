#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""End-to-end: folder of logs -> dashboard.html. No babysitting, no crashes on bad files."""
import os
from . import detect, render


def generate(src_folder, out_html=None, progress=None):
    """Parse src_folder and write a self-contained dashboard.
    Returns (out_path, stats). `progress(done, total, fname)` is optional."""
    if not os.path.isdir(src_folder):
        raise NotADirectoryError("Папка не найдена: %s" % src_folder)
    players, stats = detect.parse_folder(src_folder, progress=progress)
    if not players:
        raise ValueError("В папке не найдено ни одного пригодного лога (*.txt).")
    if out_html is None:
        out_html = os.path.join(src_folder, "dashboard.html")
    size = render.write_dashboard(players, out_html, stats)
    stats['out'] = out_html
    stats['bytes'] = size
    stats['players'] = len(players)
    return out_html, stats
