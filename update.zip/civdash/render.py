#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Assemble the self-contained dashboard HTML from the bundled template + parsed data."""
import os, sys, json


def resource_path(rel):
    """Locate a bundled resource whether running from source or a PyInstaller onefile."""
    base = getattr(sys, '_MEIPASS', None)
    if base:
        p = os.path.join(base, 'civdash', 'resources', rel)
        if os.path.exists(p):
            return p
        p = os.path.join(base, 'resources', rel)
        if os.path.exists(p):
            return p
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', rel)


def _load(rel):
    with open(resource_path(rel), encoding='utf-8') as f:
        return f.read()


def build_html(players, stats=None):
    """Return the finished dashboard HTML string for a list of player dicts."""
    template = _load('template.html')
    ffrate = json.loads(_load('ff_ratings_byname.json'))
    fftop = json.loads(_load('ff_top.json'))
    try:
        ffeff = json.loads(_load('ff_effects.json'))
    except Exception:
        ffeff = {}
    meta = {
        'legacy': (stats or {}).get('legacy', 0),
        'ideal': (stats or {}).get('ideal', 0),
        'files': (stats or {}).get('files', len(players)),
    }
    data_json = json.dumps({'players': players}, ensure_ascii=False)
    html = (template
            .replace('__DATA__', data_json)
            .replace('__FFRATE__', json.dumps(ffrate, ensure_ascii=False))
            .replace('__FFTOP__', json.dumps(fftop, ensure_ascii=False))
            .replace('__FFEFF__', json.dumps(ffeff, ensure_ascii=False))
            .replace('__META__', json.dumps(meta, ensure_ascii=False))
            .replace('{{N}}', str(len(players))))
    return html


def write_dashboard(players, out_path, stats=None):
    html = build_html(players, stats)
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(html)
    return len(html)
