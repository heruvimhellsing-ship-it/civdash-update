#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Parser for the NEW "ideal" log format (see log_spec.md).

The ideal format is line-oriented `RECORD key=value key=value ...` in UTF-8, with
an explicit revolution outcome. This parser maps those records onto the SAME
player-dict schema the legacy parser emits, so the identical dashboard renders
either source. Fields the ideal log doesn't carry are left at safe defaults.

This format does not yet exist in real tournament logs; the parser is written to
the spec and validated against a synthetic sample. When the mod starts emitting
it, only field names here may need touching.
"""
import os, re, collections

LEADER_BY_KEY = {'louis': 'louis', 'samuel': 'samuel', 'penn': 'penn', 'washington': 'washington'}


def _kv(line):
    """Parse `TAG key=value key="v v" ...` -> (tag, dict)."""
    line = line.strip()
    if not line:
        return None, {}
    m = re.match(r'^([A-Z_]+)\b(.*)$', line)
    if not m:
        return None, {}
    tag = m.group(1)
    d = {}
    for km in re.finditer(r'([a-z_]+)=("([^"]*)"|\{[^}]*\}|\[[^\]]*\]|[^\s]+)', m.group(2)):
        key = km.group(1)
        val = km.group(3) if km.group(3) is not None else km.group(2)
        d[key] = val
    return tag, d


def _i(d, k, default=None):
    try:
        return int(float(d.get(k)))
    except (TypeError, ValueError):
        return default


def default_record():
    """Every field the renderer/scoring may dereference, with safe defaults."""
    return {
        'file': '', 'prefix': '', 'player': '',
        'year_start': None, 'year_end': None, 'turns': 0, 'span': 0,
        'start_captured': False,
        'first_city_year': None, 'first_city_name': None, 'explore_time': None,
        'final_cities': 0, 'max_cities': 0, 'final_pop': 0, 'peak_pop': 0,
        'final_buildings': 0, 'uniq_buildings': 0,
        'gold_final': 0, 'gold_peak': 0,
        'sell_count': 0, 'sell_rev': 0, 'sell_amount': 0,
        'native_income': 0, 'buy_goods_spend': 0, 'prod_profit': 0, 'net_trade': 0,
        'city2_year': None, 'time_to_2nd': None, 'city1_year': None,
        'full_sells': 0, 'partial_sells': 0, 'total_visits': 0,
        'full_ship_visits': 0, 'partial_visits': 0,
        'fleet': {}, 'dominant_ship': None, 'ship_cap': 6, 'visits_list': [],
        'sells_detail': [], 'native_trades': [], 'native_avg': 0,
        'off_deaths_c': 0, 'def_deaths_c': 0, 'off_deaths': [], 'def_deaths': [],
        'king_kills': 0, 'rev_state': None, 'king_kills_strict': 0,
        'mil_king': 0, 'mil_other': 0, 'col_lost': 0, 'col_to_natives': 0,
        'player_losses': [],
        'sell_full_pct': None, 'sell_avg_amount': None,
        'loads_per_visit': None, 'full_ship_pct': None, 'flood': None,
        'buy_count': 0, 'buy_spend': 0,
        'immigrants': 0, 'trades_indian': 0,
        'wars_total': 0, 'wars_vs_players': 0, 'wars_vs_natives': 0, 'war_list': [],
        'events': 0, 'events_total': 0, 'button_events': 0,
        'tax_accept': 0, 'tax_refuse': 0, 'tax_events': 0, 'tax_final': None,
        'deaths_total': 0, 'deaths_military': 0, 'deaths_colonist': 0, 'deaths_goods': 0, 'deaths_naval': 0,
        'death_detail': {}, 'loss_breakdown': {'military': [], 'naval': [], 'colonist': [], 'goods': []},
        'top_goods': [], 'top_production': [],
        'city_analysis': [], 'dup_total': 0, 'biggest_pop': 0,
        'strat_counts': {}, 'strat_lean': None,
        'own_city_stats': {}, 'has_internal': False,
        'revolution': None,
        'max_unit_str': 0, 'max_ship_str': 0, 'gold_jump': 0,
        'suspicion': {'level': 'ok', 'flags': []},
        'nation': None, 'difficulty': None, 'founding_fathers': [], 'ff_count': 0, 'ff_recv': [],
        'rejected_fathers': [],
        'native_ffs': [], 'native_ff_bonus': 0, 'nation_native_bonus': 0,
        'king_army': None, 'rev_year': None, 'revolted': False,
        'rev_outcome': None, 'king_left_end': None, 'king_left_ships': None,
        'tier': 0, 'last_year': None,
        'city1_from_start': None, 'city2_from_start': None,
        'final_city_list': [], 'ts': [],
    }


def is_ideal(text):
    head = text[:4000]
    return ('GAME_HEADER' in head) or ('TRACKED_PLAYER=' in head) or \
           ('TURN_SNAPSHOT' in text and 'REVOLUTION_RESULT' in text)


def parse_text(text, fname=''):
    lines = text.splitlines()
    rec = default_record()
    rec['file'] = fname
    prefix = re.split(r'[_ ]', fname)[0] if fname else ''

    players = {}          # pid -> name/leader/is_human
    tracked = None
    snaps = []            # per-turn
    sells = []
    native_income = 0
    trades_indian = 0
    ff_taken, ff_rej = [], []
    deaths = collections.Counter()
    wars = []
    immigrants = 0
    bells_total = crosses_total = 0
    rev = None
    rev_result = None
    good_income = collections.Counter()

    for ln in lines:
        tag, d = _kv(ln)
        if not tag:
            continue
        if tag == 'GAME_HEADER':
            rec['difficulty'] = d.get('handicap') or rec['difficulty']
            rec['_game_mode'] = d.get('game_mode')
            if d.get('capital_terrain'):
                rec['_capital_terrain'] = d.get('capital_terrain')
        elif tag == 'PLAYER':
            pid = d.get('pid')
            players[pid] = {'name': d.get('name_ru') or d.get('name') or ('player %s' % pid),
                            'leader': d.get('leader'), 'is_human': _i(d, 'is_human', 0)}
        elif tag == 'TRACKED_PLAYER':
            tracked = ln.split('=', 1)[1].strip() if '=' in ln else None
        elif tag == 'TURN_SNAPSHOT':
            snaps.append(d)
        elif tag == 'EVENT_CITY_FOUNDED':
            snaps and snaps  # no-op; city timing derived from snapshots
            d['_city'] = True
            rec.setdefault('_cities_founded', []).append(d)
        elif tag == 'EVENT_FF':
            act = d.get('action')
            nm = d.get('ff_id') or ''
            if act == 'received' and nm:
                ff_taken.append(nm)
            elif act == 'rejected' and nm:
                ff_rej.append(nm)
        elif tag == 'EVENT_EUROPE_SALE':
            sells.append({'good': d.get('goods', ''), 'price': _i(d, 'total', 0) or 0,
                          'amount': _i(d, 'qty', 0) or 0})
            good_income[d.get('goods', '')] += _i(d, 'total', 0) or 0
        elif tag == 'EVENT_NATIVE_TRADE':
            native_income += _i(d, 'price', 0) or 0
            trades_indian += 1
        elif tag == 'EVENT_UNIT_DIED':
            deaths[d.get('unit_type', 'unknown')] += 1
        elif tag == 'EVENT_UNIT_GAINED':
            if d.get('source') == 'immigrate':
                immigrants += 1
        elif tag == 'EVENT_WAR':
            if d.get('action') == 'declare_war':
                wars.append(d)
        elif tag == 'REVOLUTION_DECLARED':
            rev = {'year': _i(d, 'year'), 'declared_in_log': True,
                   'king': {}, 'player_army_at_declare': d.get('player_army_at_declare')}
        elif tag == 'KING_FORCE_START':
            m = re.search(r'total[:=](\d+)', d.get('composition', '') or '')
            if rev is not None:
                rev.setdefault('king', {})['total'] = _i(d, 'total') or (int(m.group(1)) if m else None)
        elif tag == 'REVOLUTION_RESULT':
            rev_result = d

    # tracked player name
    name = None
    if tracked and tracked in players:
        name = players[tracked]['name']
        if players[tracked].get('leader') in LEADER_BY_KEY:
            prefix = players[tracked]['leader']
    elif players:
        # fall back to first human
        for pid, pl in players.items():
            if pl.get('is_human'):
                name = pl['name']; prefix = pl.get('leader') or prefix; break
        if name is None:
            name = list(players.values())[0]['name']
    rec['player'] = name or (fname or 'unknown')
    rec['prefix'] = prefix

    # timeseries from snapshots
    ts = []
    years = []
    for s in snaps:
        y = _i(s, 'year')
        gold = _i(s, 'gold', 0) or 0
        cities = _i(s, 'colonies', 0) or 0
        pop = _i(s, 'population', 0) or 0
        bells_total = max(bells_total, _i(s, 'bells_total', 0) or 0)
        crosses_total = max(crosses_total, _i(s, 'crosses_total', 0) or 0)
        ts.append([y, gold, cities, pop, 0])
        if y is not None:
            years.append(y)
    rec['ts'] = ts
    rec['turns'] = len(snaps)
    if years:
        rec['year_start'] = min(years); rec['year_end'] = max(years)
        rec['span'] = rec['year_end'] - rec['year_start']
        rec['last_year'] = rec['year_end']
        rec['start_captured'] = rec['year_start'] <= 1500
        rec['gold_final'] = ts[-1][1]
        rec['gold_peak'] = max((t[1] for t in ts), default=0)
        rec['final_cities'] = ts[-1][2]
        rec['max_cities'] = max((t[2] for t in ts), default=0)
        rec['final_pop'] = ts[-1][3]
        rec['peak_pop'] = max((t[3] for t in ts), default=0)

    # economy
    rec['sell_count'] = len(sells)
    rec['sell_rev'] = sum(s['price'] for s in sells)
    rec['sell_amount'] = sum(s['amount'] for s in sells)
    rec['prod_profit'] = rec['sell_rev']
    rec['native_income'] = native_income
    rec['trades_indian'] = trades_indian
    rec['net_trade'] = rec['sell_rev'] + native_income
    if sells:
        full = sum(1 for s in sells if s['amount'] >= 100)
        rec['full_sells'] = full; rec['partial_sells'] = len(sells) - full
        rec['sell_full_pct'] = round(full / len(sells) * 100)
        rec['sell_avg_amount'] = round(rec['sell_amount'] / len(sells))
    rec['sells_detail'] = [{'good': s['good'], 'price': s['price'], 'amount': s['amount']} for s in sells[:60]]
    rec['top_goods'] = good_income.most_common(6)

    # founders
    seen = set(); ff_list = []
    for x in ff_taken:
        if x not in seen:
            seen.add(x); ff_list.append(x)
    rec['founding_fathers'] = ff_list
    rec['ff_count'] = len(ff_list)
    rec['rejected_fathers'] = [x for x in dict.fromkeys(ff_rej) if x not in seen]

    # losses / immigration / wars
    MIL_KW = ('пехот', 'кавалер', 'драгун', 'ополчен', 'артиллер', 'пушк', 'мушкет', 'гренадер', 'конкистадор')
    dmil = sum(v for k, v in deaths.items() if any(w in (k or '').lower() for w in MIL_KW))
    rec['deaths_total'] = sum(deaths.values())
    rec['deaths_military'] = dmil
    rec['deaths_colonist'] = rec['deaths_total'] - dmil
    rec['death_detail'] = dict(deaths.most_common(12))
    SHIP_KW = ('корабл', 'кораб', 'галеон', 'каравелл', 'фрегат', 'флейт', 'шлюп', 'мановар', 'судно', 'галера')
    lb = {'military': [], 'naval': [], 'colonist': [], 'goods': []}
    dnaval = 0
    for _u, _c in deaths.most_common():
        s = (_u or '').lower()
        if any(w in s for w in SHIP_KW):
            lb['naval'].append([_u, _c]); dnaval += _c
        elif any(w in s for w in MIL_KW):
            lb['military'].append([_u, _c])
        else:
            lb['colonist'].append([_u, _c])
    rec['loss_breakdown'] = lb
    rec['deaths_naval'] = dnaval
    rec['immigrants'] = immigrants
    rec['wars_total'] = len(wars)

    # revolution + explicit outcome
    if rev is not None or rev_result is not None:
        rev = rev or {'declared_in_log': True, 'king': {}}
        outcome_raw = (rev_result or {}).get('outcome', '').upper()
        outcome = 'won' if outcome_raw == 'WON' else ('not_defended' if outcome_raw in ('LOST', 'ABANDONED') else 'unknown')
        rev['outcome'] = outcome
        rev['year'] = rev.get('year') or _i(rev_result or {}, 'year')
        rev['won_year'] = _i(rev_result or {}, 'year') if outcome == 'won' else None
        rev['defense_turns'] = _i(rev_result or {}, 'turns_elapsed')
        rev['king_deaths_post'] = _i(rev_result or {}, 'king_losses')
        rec['revolution'] = rev
        rec['revolted'] = True
        rec['rev_year'] = rev.get('year')
        rec['rev_outcome'] = outcome
        rec['king_army'] = (rev.get('king') or {}).get('total')
        rec['king_kills'] = rev.get('king_deaths_post') or 0
        rec['tier'] = 2 if outcome == 'won' else 1

    # nation from leader
    NAT = {'louis': 'Франция', 'samuel': 'Франция', 'penn': 'Англия', 'washington': 'Англия'}
    rec['nation'] = NAT.get(prefix)
    rec['nation_native_bonus'] = 2 if rec['nation'] == 'Франция' else 0
    NATIVE_FF = {'Покахонтас': 4, 'Роджер Вильямс': 3, 'Жан де Бребеф': 2}
    rec['native_ffs'] = [{'name': n, 'bonus': NATIVE_FF[n]} for n in ff_list if n in NATIVE_FF]
    rec['native_ff_bonus'] = sum(x['bonus'] for x in rec['native_ffs'])

    # style hint from bells vs crosses
    if bells_total or crosses_total:
        rec['own_city_stats'] = {rec['player']: {'liberty': bells_total, 'crosses': crosses_total}}
        rec['has_internal'] = True

    rec.pop('_cities_founded', None)
    return rec


def parse_folder(src, progress=None):
    import glob
    files = sorted(glob.glob(os.path.join(src, "*.txt")))
    out = []
    total = len(files)
    for i, f in enumerate(files):
        try:
            text = open(f, 'rb').read().decode('utf-8', 'replace')
            r = parse_text(text, os.path.basename(f))
            if r and r.get('turns', 0) >= 1:
                out.append(r)
        except Exception as e:
            print("skip(ideal)", os.path.basename(f), repr(e))
        if progress:
            progress(i + 1, total, os.path.basename(f))
    return out
