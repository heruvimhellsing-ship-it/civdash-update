#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Legacy parser: tournament We The People (cp1251) player logs.
Ported verbatim from the proven parse_logs.py; wrapped in a folder API with
timeseries downsampling (scale) and per-file robustness.
"""
import re, os, collections, bisect  # noqa

def dec(path):
    return open(path, 'rb').read().decode('cp1251', 'replace')

# ---- regexes ----
RE_YEAR = re.compile(r'-+\s*YEAR:\s*(-?\d+)\s*г\.\s*н\.э\.?\s*(?:-\s*([^\-\n]+?)\s*)?-\s*(.+?)\s*-\s*Gold:\s*(-?\d+)')
RE_CITY = re.compile(r'City:\s*(.+?)\s*-\s*Population:\s*(\d+)\s*-\s*Production:\s*(.+?)\s*-\s*TurnsLeft:\s*(-?\d+)')
RE_SELL = re.compile(r'SELL IN EUROPE\s*###:\s*Player\s+(.+?)\s+sold\s+(.+?)\s+PRICE:\s*(-?\d+)\s+AMOUNT:\s*(-?\d+)')
RE_BUY  = re.compile(r'BUY EUROPE UNIT\s*###:\s*The player\s+(.+?)\s+buy unit\s+(.+?)\s+PRICE:\s*(-?\d+)')
RE_DEATH = re.compile(r'##\s*DEATH UNIT\s+(.+?)\s*##\s*Owner:\s*(.+)')
RE_IMM  = re.compile(r'EUROPE IMMIGRANT\s*###:\s*Player:\s*(.+?)\s+Unit:\s*(.+)')
RE_WAR  = re.compile(r'DECLARE WAR\s*###\s*TEAM Number\s*(\d+)\s*-\s*(.*?)\s+DECLARED WAR\s+TEAM Number\s*(\d+)\s*-\s*(.*)')
RE_TRADE = re.compile(r'##TRADE WITH THE INDIANS##\s*(.+?)\s+with\s+(.+?)\s*-\s*Price:\s*(-?\d+)')
RE_EVENT = re.compile(r'###\s*EVENT\s*###\s*Player:\s*(.+?)\s*-\s*EVENT\s*(.+)')
RE_BUTTON = re.compile(r'###\s*BUTTON EVENT\s*###\s*EVENT ID\s*(\d+)\s*\|\s*(.+)')
RE_KOMBAT_ATT = re.compile(r'ATTACKER:\s*Player\s*(\d+)\s*Unit\s*(\d+)\s*\((.*?)\'s\s*(.+?)\),\s*CombatStrength=(\d+)')
RE_KOMBAT_DEF = re.compile(r'DEFENDER:\s*Player\s*(\d+)\s*Unit\s*(\d+)\s*\((.*?)\'s\s*(.+?)\),\s*CombatStrength=(\d+)')
RE_ACCEPT_TAX = re.compile(r'ACCEPT TAX RATE')
RE_REFUSE_TAX = re.compile(r'REFUSE TAX RATE')

# classify DEATH UNIT type
MILITARY = set("""Ветеран пехоты Ветеран кавалерии Ветеран драгун Пехота Кавалерия Драгуны Солдат Солдаты
Конкистадор Конкистадор на коне Поселенческое ополчение Ополчение Артиллерия Пушка Линейная пехота
Гренадер Мушкетёр Мушкетер Всадник Рейтар Кирасир Егерь""".split())
COLONISTS = set("""Свободный колонист Кабальный работник Petty Criminal Преступник Служащий Специалист
Миссионер Миссионер-иезуит Евангелист Проповедник Первопроходец Разведчик Закаленный разведчик
Эксперт Мастер Ветеран-солдат Государственный деятель Элитный государственный деятель
Опытный политик Пламенный проповедник""".split())
# everything else with a lowercase-ish good name treated as goods (Табак, Лошади, etc.)
GOODS_HINT = set("""Табак Лошади Пища Овцы Коровы Мех Кофейные зерна Кофе Руда Хлопок Конопля Элитные меха
Редкая древесина Серебро Индиго Сахар Золото Паруса Инструменты Сигары Листья коки Сокровище
Драгоценные Камни Шубы Каменная Соль Элитные шубы Красный перец Виноград Ткань Ром Ткани Шёлк Шелк
Мушкеты Пушнина Какао Специи Джут Зерно Рыба Соль Табачные изделия Одежда Вино""".split())

def classify_unit(name):
    n = name.strip(); nl = n.lower()
    # Великий полководец / адмирал — НЕ потеря: юнит-лидер исчезает, когда его вливают в отряд
    # (присоединение бонуса), а не когда его убивают. Помечаем 'leader' и не считаем в потери.
    if 'полковод' in nl or 'адмирал' in nl or 'генерал' in nl:
        return 'leader'
    # корабли/флот — отдельная категория (в т.ч. именные: "Heroine (Галеон)")
    if any(k in nl for k in ('корабл','кораб','галеон','каравелл','каракк','фрегат','флейт','флойт','флюит','шлюп',
                             'мановар','приватир','капер','каперск','судно','брандер','галера','галеас','пинас',
                             'бриг','корвет','клипер','барк','каноэ','пирог','флот')):
        return 'naval'
    # ВОЕННЫЕ (важнее всего для балла) — сначала точный список, потом ключевые слова
    if n in MILITARY: return 'military'
    if any(w in nl for w in ['пехот','кавалер','драгун','ополчен','конкистадор','артиллер','пушк','пушек','гренадер',
                             'мушкетёр','мушкетер','всадник','рейтар','кирасир','солдат','капрал','сержант','офицер',
                             'минитмен','стрел','лучник','арбалет','копейщик','пикинер','мечник','рыцар','гессен',
                             'мортир','страж','наемник','наёмник','канонир','бомбардир','улан','гусар','егер',
                             'касадор','аркебуз','терци']):
        return 'military'
    # КОЛОНИСТЫ/люди — точный список, профессии и «человеческие» прилагательные
    if n in COLONISTS: return 'colonist'
    if any(w in nl for w in ['колонист','работник','миссионер','евангелист','проповедник','разведчик','первопроход',
                             'деятель','политик','преступник','специалист','служащий','поселен','пионер','фермер',
                             'рыбак','рыболов','шахт','рудокоп','плотник','пивовар','табаков','торговец','погонщик',
                             'ткач','эксперт','мастер','проповед','капитан','лесоруб','дворян','охотник','пастух',
                             'винодел','звероло','плантатор','сахаровар','аптекар','печатник','скорняк','резчик',
                             'веревщик','верёвщик','медик','индеец','раб ','раба','старейшин','вождь','капеллан',
                             'опытн','мастит','бывал','рьян','свободн','кабальн','потомствен','африкан','пламен','закал',
                             'известн','коренн','крещ']):
        return 'colonist'
    # ТОВАРЫ/РЕСУРСЫ — только явные ресурсы (список конечен). Профессии с именем товара уже отсеяны выше.
    if n in GOODS_HINT: return 'goods'
    if any(w in nl for w in ['табак','сигар','виноград','вино','сахар','кофе','какао','специ','перец','руда','серебр',
                             'золот','лошад','ром','шёлк','шелк','шуб','мех','пушнин','соль','инструмент','оружие',
                             'мушкет','парус','веревк','верёвк','камень','мебель','сокровищ','индиго','джут','конопл',
                             'зерно','рыба','хлопок','шерст','древесин','драгоцен','кока','пиво','ячмень','хмель',
                             'одежд','мануфактур','ткан','кож','масло','жир','мука','хлеб','сыр','гончар','керамик',
                             'порох','ядр','уголь','кирпич','бисер','вампум','ладан','пряност','чай']):
        return 'goods'
    # неизвестное погибшее = скорее живой юнит, чем неучтённый товар (товары мы перечислили)
    return 'colonist'

NATIVE_MARK = ['Дикие Животные']  # animals; native tribes are many leader names

def parse_file(path):
    fname = os.path.basename(path)
    prefix = re.split(r'[_ ]', fname)[0]
    txt = dec(path)
    # determine player = most common name in YEAR lines
    year_iter = list(RE_YEAR.finditer(txt))
    namec = collections.Counter()
    for m in year_iter:
        nm = m.group(3).strip()
        nm = re.sub(r'^-+\s*YEAR:.*?-\s*', '', nm)  # fix rare malformed
        namec[nm]+=1
    if not namec:
        return None
    player = namec.most_common(1)[0][0]

    # Build turn snapshots. Split text by YEAR anchors.
    snaps = []  # each: {year, month, gold, cities:[{name,pop,prod,buildings:[]}]}
    positions = [(m.start(), m) for m in year_iter if m.group(3).strip()==player]
    # We also need city/building block after each YEAR up to next YEAR
    year_starts = [m.start() for m in year_iter]
    for idx, m in enumerate(year_iter):
        if m.group(3).strip()!=player:
            continue
        yr = int(m.group(1)); month=(m.group(2) or '').strip(); gold=int(m.group(4))
        seg_start = m.end()
        seg_end = year_iter[idx+1].start() if idx+1 < len(year_iter) else len(txt)
        seg = txt[seg_start:seg_end]
        cities=[]
        # iterate lines, city header then Buildings list until next City/CHANGE TURN
        clines = seg.split('\n')
        cur=None
        collecting=False
        for ln in clines:
            cm = RE_CITY.search(ln)
            if cm:
                cur={'name':cm.group(1).strip(),'pop':int(cm.group(2)),'prod':cm.group(3).strip(),'buildings':[]}
                cities.append(cur); collecting=False
                continue
            if 'Buildings:' in ln:
                collecting=True; continue
            if collecting and cur is not None:
                s=ln.strip()
                if not s:
                    continue
                if s.startswith('City:') or 'CHANGE TURN' in s or s.startswith('---') or s.startswith('###') or s.startswith('##') or s.startswith('***'):
                    collecting=False
                else:
                    # building name line (indented)
                    if re.match(r'^[А-ЯA-Zа-я]', s) and len(s)<60:
                        cur['buildings'].append(s)
                    else:
                        collecting=False
        snaps.append({'year':yr,'month':month,'gold':gold,'cities':cities,'idx':idx})

    # ---- events attributed to player ----
    sells=[]; buys=[]; deaths=collections.Counter(); death_detail=collections.Counter()
    imm=0; wars=[]; trades=0; events=0; buttons=0; tax_accept=0; tax_refuse=0
    other_sell_players=collections.Counter()

    for m in RE_SELL.finditer(txt):
        who=m.group(1).strip()
        if who==player:
            sells.append({'good':m.group(2).strip(),'price':int(m.group(3)),'amount':int(m.group(4))})
    for m in RE_BUY.finditer(txt):
        if m.group(1).strip()==player:
            buys.append({'unit':m.group(2).strip(),'price':int(m.group(3))})
    for m in RE_DEATH.finditer(txt):
        if m.group(2).strip()==player:
            u=m.group(1).strip(); cl=classify_unit(u)
            if cl=='leader': continue  # лидер, влитый в отряд — не потеря
            deaths[cl]+=1; death_detail[u]+=1
    imm = sum(1 for m in RE_IMM.finditer(txt) if m.group(1).strip()==player)
    for m in RE_WAR.finditer(txt):
        a=m.group(2).strip(); d=m.group(4).strip()
        if player in (a,d) and a!=d and a and d:
            wars.append({'aggressor':a,'defender':d,'as':'attacker' if a==player else 'defender',
                         'vs': d if a==player else a})
    trades = sum(1 for m in RE_TRADE.finditer(txt) if m.group(1).strip()==player or m.group(2).strip()==player)
    # события: логи спамят один и тот же квест каждый ход — считаем УНИКАЛЬНЫЕ по тексту
    ev_texts=set(); events_raw=0
    for m in RE_EVENT.finditer(txt):
        if m.group(1).strip()==player:
            events_raw+=1
            ev_texts.add(m.group(2).strip()[:60])
    events=len(ev_texts); events_total=events_raw
    buttons = len(list(RE_BUTTON.finditer(txt)))
    tax_accept = len(RE_ACCEPT_TAX.findall(txt))
    tax_refuse = len(RE_REFUSE_TAX.findall(txt))
    # финальная налоговая ставка Короля (в этих логах налог редок: ~1 на партию)
    tax_final=None
    for m in re.finditer(r'increase tax rate by\s*(\d+)\.\s*Current Tax Rate:\s*(\d+)', txt):
        tax_final=int(m.group(1))+int(m.group(2))
    tax_events=tax_accept+tax_refuse

    # ---- war of independence / revolution ----
    rev=None
    mrev=re.search(r'REVOLUTION\s*###:\s*The player\s+'+re.escape(player)+r'\s+started a revolution against\s+([^\r\n]+)', txt)
    ind_years=[int(m.group(1)) for m in re.finditer(r'INDEPENDENCE CHECK\s*###\s*Player:\s*'+re.escape(player)+r'\s+YEAR:\s*(-?\d+)', txt)]
    if mrev or ind_years:
        king={}
        rev_year=None
        if mrev:
            blk=txt[mrev.start():mrev.start()+800]
            def gg(lab):
                mm=re.search(re.escape(lab)+r':\s*(\d+)', blk); return int(mm.group(1)) if mm else None
            king={'total':gg('have units'),'line':gg('Королевский линейный пехотинец'),
                  'art':gg('Королевская артиллерия'),'drag':gg('Королевский драгун'),
                  'cav':gg('Королевский кавалерист'),'light':gg('Королевский легкий пехотинец'),
                  'ships':gg('Военный корабль')}
            pre=txt[:mrev.start()]
            ym=list(re.finditer(r'YEAR:\s*(-?\d+)\s*г', pre))
            rev_year=int(ym[-1].group(1)) if ym else (min(ind_years) if ind_years else None)
        else:
            rev_year=min(ind_years) if ind_years else None
        rev={'year':rev_year,'vs':(mrev.group(1).strip() if mrev else None),'king':king,
             'ind_first':min(ind_years) if ind_years else None,'ind_last':max(ind_years) if ind_years else None,
             'ind_checks':len(ind_years),'declared_in_log':bool(mrev)}
        # ---- ИСХОД революции (лог явного «победил» не пишет, выводим по добитой армии Короля) ----
        # Сигнал по модели Баэля: «войска кончились у Короля» = защитил; «Король ещё в силе» = не дожал.
        rev_pos = (mrev.start() if mrev else 0)
        post = txt[rev_pos:]
        king_name=None
        mkn=re.search(r'King\s+(Король[^\n]+?)\s+have units:\s*(\d+)', post)
        if mkn:
            king_name=mkn.group(1).strip()
            if king.get('total') is None: king['total']=int(mkn.group(2))
        # если имя Короля не нашли из блока — берём из vs
        if not king_name and mrev:
            king_name=(mrev.group(1).strip() if mrev else None)
        king_deaths_post=0; king_left_end=0; king_left_ships=0
        king_deaths_ships=0; king_deaths_land=0; king_nonmil_left=0
        # состав армии при объявлении: суша vs корабли (только строки юнитов, до блока --- CITY)
        land_start=None; ship_start=None
        UNIT_KW=('Гессен','Королевск','корабл','Корабл','пехотинец','артиллер','драгун','кавалер','ополчен','Мановар','фрегат','Фрегат')
        mcomp=re.search(r'have units:\s*\d+(.*?)(?:---\s*CITY|###|CHANGE TURN)', post, re.S)
        if mcomp:
            comp=[(n.strip(),int(v)) for n,v in re.findall(r'([А-Яа-я][^\n:]+?):\s*(\d+)', mcomp.group(1))]
            comp=[(n,v) for n,v in comp if any(kw.lower() in n.lower() for kw in UNIT_KW)]
            if comp:
                ship_start=sum(v for n,v in comp if 'орабл' in n.lower())
                land_start=sum(v for n,v in comp)-ship_start
        if king_name:
            dtypes=[x.strip() for x in re.findall(r'##\s*DEATH UNIT\s+(.+?)\s*##\s*Owner:\s*'+re.escape(king_name), post)]
            king_deaths_post=len(dtypes)
            king_deaths_ships=sum(1 for x in dtypes if 'орабл' in x.lower())
            king_deaths_land=king_deaths_post-king_deaths_ships
            # что осталось у Короля к концу: считаем ТОЛЬКО сухопутку — корабли топить
            # для независимости не нужно (замечание Баэля). Военный корабль/любой «корабль» исключаем.
            end_units=re.findall(r'\('+re.escape(king_name)+r'\'s\s*([^\)\n]+)', txt[-9000:])
            king_left_end=sum(1 for u in end_units if 'орабл' not in u.lower())
            king_left_ships=sum(1 for u in end_units if 'орабл' in u.lower())
            # держит ли Король ЗАХВАЧЕННОЕ СОКРОВИЩЕ (только явные индикаторы, без военных «ополчений»)
            NONMIL=['сокровищ','treasure']
            allk=re.findall(r'\('+re.escape(king_name)+r'\'s\s*([^\)\n]+)', post)
            king_nonmil_left=sum(1 for u in allk[-40:] if any(k in u.lower() for k in NONMIL))
        karmy=king.get('total') or 0
        ratio=(king_deaths_post/karmy) if karmy else 0
        # защитил: армия Короля к концу практически исчезла (≤2) и уничтожена бОльшая часть
        # «защитил» = сухопутная армия Короля практически уничтожена (осталась горстка).
        # Корабли Короля не считаем — их топить для независимости не нужно.
        if not king_name:
            outcome='unknown'
        elif karmy:  # знаем размер армии при объявлении
            outcome='won' if (king_left_end<=4 and (ratio>=0.6 or king_deaths_post>=karmy)) else 'not_defended'
        else:  # размер армии не залогирован — судим по «сухопутка Короля исчезла» + масштабу боёв
            if king_left_end<=3 and king_deaths_post>=50: outcome='won'
            elif king_left_end>3: outcome='not_defended'
            else: outcome='unknown'
        rev['outcome']=outcome; rev['king_deaths_post']=king_deaths_post
        rev['king_left_end']=king_left_end; rev['king_left_ships']=king_left_ships; rev['king_name']=king_name
        rev['land_start']=land_start; rev['ship_start']=ship_start
        rev['king_deaths_land']=king_deaths_land; rev['king_deaths_ships']=king_deaths_ships
        rev['king_nonmil_left']=king_nonmil_left
        # год, когда добили последнего юнита Короля = год фактической защиты независимости.
        # После него партия ещё идёт до лимита ходов, но это уже мирная доигровка.
        won_year=None; defense_turns=None
        if king_name:
            dpos=[m.start() for m in re.finditer(r'##\s*DEATH UNIT\s+.+?##\s*Owner:\s*'+re.escape(king_name), post)]
            if dpos:
                war=post[:dpos[-1]]
                yb=re.findall(r'YEAR:\s*(\d+)', war)
                won_year=int(yb[-1]) if yb else None
                # ВАЖНО: в поздней игре год = ~4 хода (кварталы Янв/Апр/Июл/Окт), поэтому
                # длительность обороны меряем в ХОДАХ (CHANGE TURN), а не в календарных годах.
                defense_turns=war.count('CHANGE TURN')
        rev['won_year']=won_year
        rev['defense_years']=(won_year-rev_year) if (won_year and rev_year) else None
        rev['defense_turns']=defense_turns

    # ---- nation / difficulty / founding fathers ----
    md=re.search(re.escape(player)+r'\s*\|\s*[^|\n]*\|\s*Difficulty:\s*([^\n\r]+)', txt)
    difficulty=md.group(1).strip() if md else None
    founding_fathers=[x.strip() for x in re.findall(r'Received the Founding Father:\s*([^\n\r]+)', txt)]
    # dedupe preserve order
    seen=set(); ff_list=[]
    for x in founding_fathers:
        if x not in seen: seen.add(x); ff_list.append(x)
    # ОТКАЗЫ от отцов (лог: "... Player: NAME - Rejected the Founding Father: X")
    rej_seen=set(); rejected_ff=[]
    for m in re.finditer(r'Player:\s*'+re.escape(player)+r'\s*-\s*Rejected the Founding Father:\s*([^\n\r]+)', txt):
        nm=m.group(1).strip()
        if nm not in rej_seen and nm not in seen:
            rej_seen.add(nm); rejected_ff.append(nm)
    NAT={'Франции':'Франция','Англии':'Англия','Испании':'Испания','Дании':'Дания',
         'Португалии':'Португалия','Нидерландов':'Нидерланды','Швеции':'Швеция'}
    nation=None
    if rev and rev.get('vs'):
        m2=re.search(r'Король\s+(\S+)', rev['vs'])
        if m2: nation=NAT.get(m2.group(1).strip(), m2.group(1).strip())
    # native-relations levers from KLT Excel rubric
    NATIVE_FF={'Покахонтас':4,'Роджер Вильямс':3,'Жан де Бребеф':2}
    native_ffs=[{'name':n,'bonus':NATIVE_FF[n]} for n in ff_list if n in NATIVE_FF]
    native_ff_bonus=sum(x['bonus'] for x in native_ffs)
    nation_native_bonus=2 if nation=='Франция' else 0  # France: +2 attitude (Data sheet)

    # ---- derive metrics ----
    years=[s['year'] for s in snaps]
    y0,y1=min(years),max(years)
    # first city founding
    first_city_year=None; first_city_name=None
    for s in snaps:
        if s['cities']:
            first_city_year=s['year']; first_city_name=s['cities'][0]['name']; break
    start_captured = y0<=1500
    explore_time = (first_city_year - y0) if (first_city_year is not None and start_captured) else None

    # per-turn aggregates
    ts=[]
    for s in snaps:
        ncities=len(s['cities']); pop=sum(c['pop'] for c in s['cities'])
        bld=sum(len(c['buildings']) for c in s['cities'])
        ts.append({'year':s['year'],'gold':s['gold'],'cities':ncities,'pop':pop,'buildings':bld})
    # City roster: latest known state per city name (+ how often seen)
    roster={}
    for s in snaps:
        for c in s['cities']:
            nm=c['name']
            r=roster.setdefault(nm,{'seen':0,'pop':0,'buildings':[],'last_idx':-1})
            r['seen']+=1
            if s['idx']>=r['last_idx']:
                r['last_idx']=s['idx']; r['pop']=c['pop']; r['buildings']=c['buildings']
    max_cities=max((t['cities'] for t in ts), default=0)
    # "established" cities = those seen in a meaningful share of snapshots (filters renames/transient)
    thr=max(2, len(snaps)*0.10)
    established={n:r for n,r in roster.items() if r['seen']>=thr}
    if not established:  # fallback: keep top max_cities most-seen
        established=dict(sorted(roster.items(), key=lambda kv:-kv[1]['seen'])[:max(1,max_cities)])
    final_cities=len(established)
    # города могли не попасть в один снимок одновременно (формат YEAR печатает по одному) —
    # «основано всего» не может быть меньше числа закрепившихся городов
    max_cities=max(max_cities, final_cities)
    final_pop=sum(r['pop'] for r in established.values())
    all_buildings=[b for r in established.values() for b in r['buildings']]
    final_buildings=len(all_buildings)
    uniq_buildings=len(set(all_buildings))
    peak_pop=max((t['pop'] for t in ts), default=0)
    golds=[t['gold'] for t in ts]
    gold_final=golds[-1] if golds else 0
    gold_peak=max(golds) if golds else 0

    sell_rev=sum(s['price'] for s in sells)
    sell_amt=sum(s['amount'] for s in sells)
    # ---- sell efficiency: full holds vs dribbles, full-galleon batching, market flooding ----
    SLOT=100  # cargo slot capacity in WTP
    sell_full_pct=None; sell_avg_amount=None; loads_per_visit=None; full_ship_pct=None; flood=None
    if sells:
        full=sum(1 for s in sells if s['amount']>=SLOT)
        sell_full_pct=round(full/len(sells)*100)
        sell_avg_amount=round(sell_amt/len(sells))
        # batching by turn (one CHANGE TURN chunk ~ one market visit)
        visits=[]
        for ch in txt.split('CHANGE TURN'):
            c=sum(1 for m in RE_SELL.finditer(ch) if m.group(1).strip()==player)
            if c>0: visits.append(c)
        if visits:
            loads_per_visit=round(sum(visits)/len(visits),1)
            full_ship_pct=round(sum(1 for v in visits if v>=6)/len(visits)*100)
        # flooding: avg price/unit drop on heavily-sold goods (>=6 loads)
        byg=collections.defaultdict(list)
        for s in sells:
            if s['amount']>0: byg[s['good']].append(s['price']/s['amount'])
        eros=[]
        for g,seq in byg.items():
            if len(seq)>=6:
                mx=max(seq); last=sum(seq[-3:])/len(seq[-3:])
                if mx>0: eros.append(max(0.0,1-last/mx))
        if eros: flood=round(sum(eros)/len(eros)*100)
    buy_spend=sum(b['price'] for b in buys)
    # top sold goods
    goodc=collections.Counter()
    for s in sells: goodc[s['good']]+=s['price']
    top_goods=goodc.most_common(6)
    # production focus
    prodc=collections.Counter()
    for s in snaps:
        for c in s['cities']:
            prodc[c['prod']]+=1
    # ---- building analysis (per established city) ----
    BCLASS={
      'религия':['Часовня','Церковь','Собор','Кафедральн','Миссия','Монастыр','Храм'],
      'политика/культура':['Ратуша','Мэрия','Дворец правительства','Газета','Печатный станок','Типография','Университет','Колледж','Школа','Библиотека','Театр','Мэрия'],
      'военное':['Форт','Крепость','Частокол','Бастион','Арсенал','Оружейн','Военный склад','Кузнечн','Кузниц','Заграждение','рогатка','Пушечн','Магазин оружия'],
      'производство':['Лесопилка','Шахта','Рудник','фабрика','Фабрика','цех','Цех','Дом ткача','Дом Красильщика','Ткац','Табачн','Ромовар','Пивовар','Сигарн','Мебельн','Плотниц','Мастерская','Мануфактур'],
      'торговля/склад':['Рынок','рынок','Склад','склад','Пирс','Таможня','Биржа'],
      'инфраструктура':['Док','Путевая станция','Колодец','Больниц','Медицинск','Таверна','Конюшн','Пекарн','Мельниц'],
    }
    def classify_building(b):
        for cat,kws in BCLASS.items():
            if any(k in b for k in kws): return cat
        return 'прочее'
    city_analysis=[]; strat=collections.Counter(); dup_total=0; biggest_pop=0
    for n,r in sorted(established.items(), key=lambda kv:-kv[1]['pop']):
        bl=r['buildings']
        cnt=collections.Counter(bl)
        dups=[f"{k}×{v}" for k,v in cnt.items() if v>1]
        dup_total+=sum(v-1 for v in cnt.values() if v>1)
        for b in bl: strat[classify_building(b)]+=1
        biggest_pop=max(biggest_pop,r['pop'])
        city_analysis.append({'name':n,'pop':r['pop'],'nbuild':len(bl),'dups':dups,
                              'blist':[[k,v] for k,v in cnt.most_common()],
                              'has_2saw':cnt.get('Лесопилка',0)>=2,'has_2mine':cnt.get('Шахта',0)+cnt.get('Рудник',0)>=2})
    # ---- own-city internal state from '--- CITY ---' blocks (rare: ~10 sessions) ----
    RE_CITYBLK=re.compile(r'---\s*CITY\s*---\s*City:\s*(.+)')
    own_names=set(established.keys())
    blk_idx=[(m.start(), m.group(1).strip()) for m in RE_CITYBLK.finditer(txt)]
    own_city_stats={}
    for i,(pos,nm) in enumerate(blk_idx):
        if nm not in own_names: continue
        end=blk_idx[i+1][0] if i+1<len(blk_idx) else pos+3500
        seg=txt[pos:end]
        def gv(lab):
            mm=re.search(r'(?:^|\n)\s*'+re.escape(lab)+r':\s*(-?\d+)', seg)
            return int(mm.group(1)) if mm else None
        own_city_stats[nm]={
            'food':gv('Пища'),'ore':gv('Руда'),'lumber':gv('Строительный лес'),
            'gold':gv('Золото'),'silver':gv('Серебро'),'gems':gv('Драгоценные камни'),
            'production':gv('Производство'),'liberty':gv('Колокола свободы'),
            'crosses':gv('Кресты'),'culture':gv('Культура'),'health':gv('Здоровье'),
            'education':gv('Образование'),
        }
    has_internal=len(own_city_stats)>0

    # strategy lean (soft, heuristic; religion inflated by event-granted Часовня so weight down)
    strat_soft=dict(strat)
    strat_lean=None
    rel=strat.get('религия',0); pol=strat.get('политика/культура',0); mil=strat.get('военное',0); prod=strat.get('производство',0)
    lean_scores={'религия':rel*0.6,'политика/культура':pol*1.3,'военное':mil*1.1,'производство/экономика':prod*1.0}
    if any(lean_scores.values()):
        strat_lean=max(lean_scores.items(), key=lambda kv:kv[1])[0]

    # ---- trade profit streams & 2nd-city timing ----
    native_income=sum(int(m.group(3)) for m in RE_TRADE.finditer(txt) if (m.group(1).strip()==player or m.group(2).strip()==player))
    RE_BUYG=re.compile(r'BUY IN EUROPE\s*###:\s*Player\s+(.+?)\s+buy\s+(.+?)\s+PRICE:\s*(-?\d+)\s+AMOUNT:\s*(-?\d+)')
    buy_goods_spend=sum(int(m.group(3)) for m in RE_BUYG.finditer(txt) if m.group(1).strip()==player)
    prod_profit=sell_rev
    net_trade=sell_rev+native_income-buy_goods_spend
    city_first={}
    for s in snaps:
        for c in s['cities']:
            if c['name'] not in city_first: city_first[c['name']]=s['year']
    founds=sorted([city_first[n] for n in established if n in city_first])
    city1_year=founds[0] if founds else None
    city2_year=founds[1] if len(founds)>=2 else None
    time_to_2nd=(city2_year-city1_year) if (city1_year is not None and city2_year is not None and start_captured) else None

    # ---- combat signals (year-tagged) for plausibility / cheat detection ----
    import bisect
    ypos=sorted([(m.start(), int(m.group(1))) for m in RE_YEAR.finditer(txt) if m.group(3).strip()==player])
    ystarts=[p for p,_ in ypos]; yvals=[y for _,y in ypos]
    def year_at(pos):
        if not ystarts: return None
        j=bisect.bisect_right(ystarts,pos)-1
        return yvals[j] if j>=0 else (yvals[0] if yvals else None)
    RE_KMB=re.compile(r'(?:ATTACKER|DEFENDER):\s*Player\s*\d+\s*Unit\s*\d+\s*\((.*?)\'s\s*(.+?)\),\s*CombatStrength=(\d+)')
    SHIPKW=['корабл','Кораб','Каравелл','Галеон','Фрегат','Каракк','Флейт','Шлюп','Мановар','Линейный корабль']
    own_combat=[]  # (year, name, strength, is_ship)
    max_unit_str=0; max_ship_str=0; early_strong=[]
    for m in RE_KMB.finditer(txt):
        owner=m.group(1).strip(); name=m.group(2).strip(); s=int(m.group(3))
        if owner==player or owner=="":
            yr=year_at(m.start())
            is_ship=any(k in name for k in SHIPKW)
            if s>max_unit_str: max_unit_str=s
            if is_ship and s>max_ship_str: max_ship_str=s
            if yr is not None and yr<1560 and s>2000:
                early_strong.append({'year':yr,'name':name,'str':s})
    # gold max single-turn jump
    gold_jump=max([ts[i]['gold']-ts[i-1]['gold'] for i in range(1,len(ts))] or [0])

    # ---- детализация для drill-down ----
    # продажи: полные/недогруз
    full_sells=sum(1 for s in sells if s['amount']>=100)
    partial_sells=len(sells)-full_sells
    visits2=[]
    for ch in txt.split('CHANGE TURN'):
        c=sum(1 for m in RE_SELL.finditer(ch) if m.group(1).strip()==player)
        if c>0: visits2.append(c)
    total_visits=len(visits2)
    # флот игрока и вместимость (слотов): полнота корабля судится по вместимости его судов
    SLOTCAP={'Каравелла':2,'Каракка':4,'Галеон':6,'Флейт':4,'Флойт':4,'Фрегат':4,'Торговый корабль':4,
             'Мановар':6,'Линейный корабль':6,'Шлюп':2,'Каперский корабль':4,'Военный корабль':6,'Приватир':4}
    fleet=collections.Counter(re.findall(r'The ship [^\n]*?\(([^)\n]+)\)', txt))
    fleet={k:v for k,v in fleet.items() if k in SLOTCAP}
    dominant_ship=max(fleet.items(), key=lambda kv:kv[1])[0] if fleet else None
    ship_cap=SLOTCAP.get(dominant_ship,6) if dominant_ship else 6
    full_ship_visits=sum(1 for v in visits2 if v>=ship_cap); partial_visits=total_visits-full_ship_visits
    full_ship_pct=round(full_ship_visits/total_visits*100) if total_visits else None
    visits_list=visits2[:120]
    sells_detail=[{'good':s['good'],'price':s['price'],'amount':s['amount']} for s in sells][:120]
    # торговля с индейцами: список
    native_trades=[]
    for m in RE_TRADE.finditer(txt):
        a=m.group(1).strip(); b=m.group(2).strip(); pr=int(m.group(3))
        if a==player or b==player:
            native_trades.append({'partner':(b if a==player else a),'price':pr,'year':year_at(m.start())})
    native_trades=native_trades[:120]
    native_avg=round(sum(t['price'] for t in native_trades)/len(native_trades)) if native_trades else 0
    # бои: потери игрока в контексте (оборона/атака) + убитые юниты Короля
    # ВАЖНО: лог турнирный = полная МНОГОПОЛЬЗОВАТЕЛЬСКАЯ игра. В нём фигурируют бои
    # всех игроков (Мем ди Са, Эрнан Кортес, ...), не только отслеживаемого. Поэтому
    # king_kills и врага в потерях засчитываем ТОЛЬКО когда игрок реально участник боя.
    RE_ATTx=re.compile(r"ATTACKER:[^\n]*?\('?([^\n']*)'s\s*(.+?)\),\s*CombatStrength=(\d+)")
    RE_DEFx=re.compile(r"DEFENDER:[^\n]*?\('?([^\n']*)'s\s*(.+?)\),\s*CombatStrength=(\d+)")
    kpos=[m.start() for m in re.finditer(r'\*\*\* KOMBAT', txt)]
    off_deaths=[]; def_deaths=[]; king_kills=0
    player_losses=[]  # {unit, year, role, enemy, enemy_cat, kind}
    def enemy_cat(name):
        n=(name or '').strip()
        if n.startswith('Король'): return 'king'
        if 'Дикие Животные' in n: return 'animals'
        if n=='' or n=='противник': return 'unknown'
        return 'native'  # племя или европеец (различить надёжно нельзя)
    for i,pos in enumerate(kpos):
        end=kpos[i+1] if i+1<len(kpos) else pos+700
        seg=txt[pos:min(end,pos+700)]
        am=RE_ATTx.search(seg); dm=RE_DEFx.search(seg)
        if not(am and dm): continue
        att_owner=am.group(1).strip(); att_type=am.group(2).strip(); att_str=int(am.group(3))
        def_owner=dm.group(1).strip(); def_type=dm.group(2).strip(); def_str=int(dm.group(3))
        yr=year_at(pos)
        # игрок — участник этого боя? (по имени; пустой owner НЕ считаем игроком для атрибуции)
        p_is_att=(att_owner==player); p_is_def=(def_owner==player)
        p_in_fight = p_is_att or p_is_def
        for dmm in RE_DEATH.finditer(seg):
            du=dmm.group(1).strip(); do=dmm.group(2).strip()
            # убитый юнит Короля засчитываем игроку ТОЛЬКО если игрок — вторая сторона боя
            if do.startswith('Король') and p_in_fight:
                king_kills+=1
            if do==player:
                cl=classify_unit(du)
                if cl not in ('military','colonist'): continue
                # роль игрока: по стороне (нападал/защищался), не по типу юнита
                if p_is_att and not p_is_def:
                    role='атака'; enemy=def_owner
                elif p_is_def and not p_is_att:
                    role='оборона'; enemy=att_owner
                else:
                    # неоднозначно (обе стороны с именем игрока — клоны в турнире, или пустой owner):
                    # роль по типу, при совпадении типов — слабейший обычно проигрывает
                    if att_type==def_type:
                        role='атака' if att_str<def_str else 'оборона'
                    else:
                        role='атака' if du==att_type else 'оборона'
                    enemy=def_owner if role=='атака' else att_owner
                # враг не может быть самим игроком/пустым → «противник» (лог не различает)
                if (not enemy) or enemy==player:
                    enemy='противник'
                ec=enemy_cat(enemy)
                player_losses.append({'unit':du,'year':yr,'role':role,'enemy':enemy,'ecat':ec,'kind':cl})
                if cl=='military':
                    (off_deaths if role=='атака' else def_deaths).append({'year':yr,'unit':du})
    off_deaths_c=len(off_deaths); def_deaths_c=len(def_deaths)
    mil_king=sum(1 for l in player_losses if l['kind']=='military' and l['ecat']=='king')
    mil_other=sum(1 for l in player_losses if l['kind']=='military' and l['ecat']!='king')
    col_lost=sum(1 for l in player_losses if l['kind']=='colonist')
    col_to_natives=sum(1 for l in player_losses if l['kind']=='colonist' and l['ecat'] in ('native','animals'))
    # состояние на момент революции
    rev_state=None
    if rev and rev.get('year') is not None:
        ry=rev['year']; best=None
        for s in snaps:
            if s['cities'] and s['year']<=ry: best=s
        if best is None:
            for s in snaps:
                if s['cities']: best=s; break
        if best:
            rev_state={'year':best['year'],'cities':len(best['cities']),
                       'pop':sum(c['pop'] for c in best['cities']),
                       'buildings':sum(len(c['buildings']) for c in best['cities'])}

    # ---- FF received with year (both formats) ----
    ff_recv=[]
    for m in re.finditer(r'Received the Founding Father:\s*([^\n\r]+)', txt):
        nm=m.group(1).strip()
        pre=txt[max(0,m.start()-45):m.start()]
        ym=re.search(r'Year:\s*(-?\d+)', pre)
        yr=int(ym.group(1)) if ym else year_at(m.start())
        ff_recv.append({'name':nm,'year':yr})
    ff_years=[f['year'] for f in ff_recv if f['year'] is not None]
    ff_first_year=min(ff_years) if ff_years else None
    malinche_year=None
    for f in ff_recv:
        if 'алинче' in f['name']:
            malinche_year=f['year']; break

    # ---- year-tagged income for "gold from nowhere" ----
    sell_years=[(year_at(m.start()), int(m.group(3))) for m in RE_SELL.finditer(txt) if m.group(1).strip()==player]
    trade_years=[(year_at(m.start()), int(m.group(3))) for m in RE_TRADE.finditer(txt) if (m.group(1).strip()==player or m.group(2).strip()==player)]
    gold_anom=None
    for i in range(1,len(ts)):
        y0s,g0=ts[i-1]['year'],ts[i-1]['gold']; y1s,g1=ts[i]['year'],ts[i]['gold']
        delta=g1-g0
        if delta<=3000: continue
        inc=sum(v for (yy,v) in sell_years if yy is not None and y0s<yy<=y1s)+sum(v for (yy,v) in trade_years if yy is not None and y0s<yy<=y1s)
        if delta-inc>3000:
            gold_anom={'year':y1s,'delta':delta,'income':inc}; break

    # ---- suspicion rules: severity 'violation' (почти точно нельзя) | 'anomaly' (проверить) ----
    flags=[]
    if rev and rev.get('declared_in_log') and max_cities<2:
        flags.append({'rule':'revolt_under_2_cities','severity':'violation','evidence':'Объявил революцию при %d городе — организатор требует минимум 2 города'%max_cities})
    if rev and rev.get('year') is not None and rev['year']<1565:
        flags.append({'rule':'early_revolution','severity':'anomaly','evidence':'Революция в %d — крайне рано (защита раньше ~1585 маловероятна). Теоретически возможно при удачном старте, но проверить'%rev['year']})
    if malinche_year is not None and malinche_year<1514:
        flags.append({'rule':'father_too_early','severity':'anomaly','evidence':'Малинче в %d — необычно рано. Возможно при сильном старте (соседи-Тупи, продажа ружей, быстрая ратуша, бесплатные маститые), но проверить'%malinche_year})
    elif ff_first_year is not None and ff_first_year<1505:
        flags.append({'rule':'father_too_early','severity':'anomaly','evidence':'Первый отец-основатель в %d — необычно рано, проверить'%ff_first_year})
    # NB: «золото из ниоткуда» и сырую боевую силу авто-флагом НЕ ставим (много легитимных источников/бонусов) — оставлены справкой.
    if (y1-y0)>=80 and peak_pop<=9 and max_cities<=1 and gold_final>1500:
        flags.append({'rule':'pop_stagnation','severity':'anomaly','evidence':'Партия %d лет, но 1 город и население ≤9 при золоте %d — необычно, проверить'%(y1-y0,gold_final)})
    has_v=any(f['severity']=='violation' for f in flags)
    has_a=any(f['severity']=='anomaly' for f in flags)
    lvl='violation' if has_v else ('anomaly' if has_a else 'ok')
    suspicion={'level':lvl,'flags':flags}

    # native relations
    native_wars=[w for w in wars if w['vs'] in NATIVE_MARK]
    player_wars=[w for w in wars if w['vs'] not in NATIVE_MARK]
    deaths_mil=deaths.get('military',0); deaths_col=deaths.get('colonist',0); deaths_goods=deaths.get('goods',0)
    deaths_naval=deaths.get('naval',0)
    # полная разбивка потерь по категориям (тот же источник, что и totals) — чтобы карточка была консистентна
    loss_breakdown={'military':[],'naval':[],'colonist':[],'goods':[]}
    for _u,_c in death_detail.most_common():
        loss_breakdown[classify_unit(_u)].append([_u,_c])

    return {
        'file':fname,'prefix':prefix,'player':player,
        'year_start':y0,'year_end':y1,'turns':len(snaps),'span':y1-y0,
        'start_captured':start_captured,
        'first_city_year':first_city_year,'first_city_name':first_city_name,'explore_time':explore_time,
        'final_cities':final_cities,'max_cities':max_cities,'final_pop':final_pop,'peak_pop':peak_pop,
        'final_buildings':final_buildings,'uniq_buildings':uniq_buildings,
        'gold_final':gold_final,'gold_peak':gold_peak,
        'sell_count':len(sells),'sell_rev':sell_rev,'sell_amount':sell_amt,
        'native_income':native_income,'buy_goods_spend':buy_goods_spend,'prod_profit':prod_profit,'net_trade':net_trade,
        'city2_year':city2_year,'time_to_2nd':time_to_2nd,'city1_year':city1_year,
        'full_sells':full_sells,'partial_sells':partial_sells,'total_visits':total_visits,
        'full_ship_visits':full_ship_visits,'partial_visits':partial_visits,
        'fleet':dict(fleet),'dominant_ship':dominant_ship,'ship_cap':ship_cap,'visits_list':visits_list,
        'sells_detail':sells_detail,'native_trades':native_trades,'native_avg':native_avg,
        'off_deaths_c':off_deaths_c,'def_deaths_c':def_deaths_c,'off_deaths':off_deaths[:60],'def_deaths':def_deaths[:60],
        'king_kills':(rev.get('king_deaths_post') if (rev and rev.get('king_deaths_post')) else king_kills),'rev_state':rev_state,
        'king_kills_strict':king_kills,
        'mil_king':mil_king,'mil_other':mil_other,'col_lost':col_lost,'col_to_natives':col_to_natives,
        'player_losses':player_losses[:80],
        'sell_full_pct':sell_full_pct,'sell_avg_amount':sell_avg_amount,
        'loads_per_visit':loads_per_visit,'full_ship_pct':full_ship_pct,'flood':flood,
        'buy_count':len(buys),'buy_spend':buy_spend,
        'immigrants':imm,'trades_indian':trades,
        'wars_total':len(wars),'wars_vs_players':len(player_wars),'wars_vs_natives':len(native_wars),
        'war_list':wars[:40],
        'events':events,'events_total':events_total,'button_events':buttons,
        'tax_accept':tax_accept,'tax_refuse':tax_refuse,'tax_events':tax_events,'tax_final':tax_final,
        'deaths_total':sum(deaths.values()),'deaths_military':deaths_mil,'deaths_colonist':deaths_col,'deaths_goods':deaths_goods,'deaths_naval':deaths_naval,
        'death_detail':dict(death_detail.most_common(12)),
        'loss_breakdown':loss_breakdown,
        'top_goods':top_goods,'top_production':prodc.most_common(8),
        'city_analysis':city_analysis,'dup_total':dup_total,'biggest_pop':biggest_pop,
        'strat_counts':strat_soft,'strat_lean':strat_lean,
        'own_city_stats':own_city_stats,'has_internal':has_internal,
        'revolution':rev,
        'max_unit_str':max_unit_str,'max_ship_str':max_ship_str,'gold_jump':gold_jump,
        'suspicion':suspicion,
        'nation':nation,'difficulty':difficulty,'founding_fathers':ff_list,'ff_count':len(ff_list),
        'ff_recv':[f for f in ff_recv if f.get('year') is not None][:40],
        'rejected_fathers':rejected_ff,
        'native_ffs':native_ffs,'native_ff_bonus':native_ff_bonus,'nation_native_bonus':nation_native_bonus,
        'king_army':(rev['king'].get('total') if (rev and rev.get('declared_in_log')) else None),
        'rev_year':(rev['year'] if rev else None),
        'revolted':bool(rev),
        'rev_outcome':(rev.get('outcome') if rev else None),
        'king_left_end':(rev.get('king_left_end') if rev else None),
        'king_left_ships':(rev.get('king_left_ships') if rev else None),
        'tier':(2 if (rev and rev.get('outcome')=='won') else (1 if rev else 0)),
        'last_year':y1,
        'city1_from_start':(city1_year-y0) if (city1_year is not None) else None,
        'city2_from_start':(city2_year-y0) if (city2_year is not None) else None,
        'final_city_list':[{'name':n,'pop':r['pop'],'buildings':len(r['buildings']),'seen':r['seen']}
                            for n,r in sorted(established.items(), key=lambda kv:-kv[1]['pop'])],
        'timeseries':ts,
    }

# ---- downsample heavy per-player arrays so the embedded JSON stays lean at 5000 players ----
def _downsample(seq, cap):
    n = len(seq)
    if n <= cap:
        return seq
    step = n / float(cap)
    out = [seq[int(i*step)] for i in range(cap)]
    if out and seq and out[-1] is not seq[-1]:
        out[-1] = seq[-1]
    return out

def _trim(rec):
    """Shrink the embedded payload so a 5000-player dashboard stays ~20 MB.
    - timeseries: downsample to <=45 points and store as compact arrays
      [year, gold, cities, pop, buildings] (rehydrated to objects in JS on load).
    - detail arrays used only in the card/modals: capped."""
    if not rec:
        return rec
    ts = _downsample(rec.get('timeseries') or [], 45)
    rec['ts'] = [[t.get('year'), t.get('gold'), t.get('cities'), t.get('pop'), t.get('buildings')] for t in ts]
    rec.pop('timeseries', None)
    for key, cap in (('sells_detail', 60), ('native_trades', 60), ('player_losses', 50),
                     ('off_deaths', 40), ('def_deaths', 40), ('visits_list', 80)):
        v = rec.get(key)
        if isinstance(v, list) and len(v) > cap:
            rec[key] = v[:cap]
    return rec

def parse_folder(src, progress=None):
    """Parse every *.txt in src as a legacy log. Returns list of player dicts.
    progress(done, total, fname) is called per file if provided."""
    import glob
    files = sorted(glob.glob(os.path.join(src, "*.txt")))
    out = []
    total = len(files)
    for i, f in enumerate(files):
        try:
            r = parse_file(f)
            if r and r.get('turns', 0) >= 1:
                out.append(_trim(r))
        except Exception as e:  # never let one bad file kill the batch
            print("skip(legacy)", os.path.basename(f), repr(e))
        if progress:
            progress(i + 1, total, os.path.basename(f))
    return out
