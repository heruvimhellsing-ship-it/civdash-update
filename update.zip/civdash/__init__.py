#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""civdash — Civ4Col / We The People tournament log dashboard generator."""
__version__ = "3.3"
